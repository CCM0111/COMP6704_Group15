# Experiment Comparability

原192条适合检查四种实现是否求解了同一个问题，并讨论正则化、支撑与各机器本地变化；跨方法速度比较采用单独标注的E01/E02同机32次补充。两类证据不可混为一个正式批次。

## 共同数学问题与数据

`P(β)=||Xβ-y||²/(2n)+λ||β||₁`，n为训练样本数。λ>0，无L2、样本权重、正系数限制。所有求解器不另拟合截距。

先划分，再仅用训练样本拟合每列均值与总体标准差（ddof=0）；标准差<1e-12的列scale=1。y只减训练均值，不缩放。预测使用 `y_mean+X_processed@β`；原特征系数为 `β/x_scale`，截距为 `y_mean-x_mean@(β/x_scale)`。测试集应用训练统计量，不重新拟合。X是float64/F-order，y为一维float64，索引int64。

Diabetes使用scaled=False，442行，训练353/测试89。合成AR(1) master1250×400、φ=.3、噪声σ=1；10个±2信号均在前100列，S100/S200/S400只截列，共享y与行号。X、支撑/符号、噪声、划分分别为独立PCG64 seed2101、2102、2103、20261021。

λ_max=||X.T@y||∞/n。DIA/S200固定比例.01/.03/.10/.30/1；E11/E12保持E02的绝对λ。没有用测试RMSE挑选λ。E01(DIA) λ=4.409499843964595；E02(S200) λ=.22281994907926272。

## 证据矩阵

| 证据 | 问题 | 方法 | 每配置运行 | summary总数 | 可以回答 |
|---|---|---|---|---|---|
| original | E01–E12 | 四方法，来自各自机器 | 1 trace+3 timing | 192 | 同问题数值正确性、正则/支撑、各host本地趋势 |
| same_machine_supplement | 仅E01/E02 | 四份原solver，同一runner/进程/机器 | 1 trace+3 timing | 32 | 这两个问题上这四份Python实现的同机效率与轨迹 |

原协议全部配置max_iterations=10000；DIA/S100/S200/S400预算分别10/20/30/45秒；主相对gap容差1e-6。新增补充完全继承E01/E02的配置，无调参。

## 统一停止与正确性

独立评价从β重算r=y−Xβ，构造对偶可行θ并计算D、带符号G=P−D。S=max(||y||²/(2n),1e-12)。停止要求量有限、G≥−1e-12S、对偶相对可行性违例≤1e-12、max(G,0)/S≤1e-6。原始CSV保留微小负gap，不以绝对值美化。

参考解使用独立sklearn Lasso(alpha=λ, fit_intercept=False, cyclic, tol=1e-13, max_iter=200000, precompute=False, warm_start=False, positive=False)，参考证书gap/S≤1e-10。目标差P−P_ref与通用gap是两件事，不能混淆。sklearn参考属于CD家族，其任务是认证数值值，不算第五个参赛算法。

KKT分支使用真正的β=0；支撑统计阈值固定为1e-6 max(1,y_rms)，不裁剪最终β。ADMM残差仅作诊断，不能取代通用gap停止。

## 同机补充的计时

新增机器环境如下，同时列出原包方便识别不同host。六个包版本均为协议锁定版本；ISTA原Python不是正式要求的3.12.x。

| 来源 | CPU | 物理核 | RAM | Python | 实际线程观测 |
|---|---|---|---|---|---|
| ISTA原包 | INTEL(R) XEON(R) PLATINUM 8573C | 5 | 5.80853 GiB | 3.13.5 | 有观测记录 |
| FISTA原包 | Apple M4 | 10 | 24 GiB | 3.12.2 | 未由threadpoolctl暴露 |
| CD原包 | Apple M2 | 8 | 16 GiB | 3.12.6 | 未由threadpoolctl暴露 |
| ADMM原包 | Apple M2 | 8 | 8 GiB | 3.12.5 | 未由threadpoolctl暴露 |
| 新增32次补充 | Apple M2 | 8 | 8 GiB | 3.12.5 | 未由threadpoolctl暴露 |

新增32次顺序执行，无并行实验。每个repeat按dataset循环，并按repeat+dataset_index旋转ISTA/FISTA/CD/ADMM顺序，使每方法在每问题的四轮各占一个位置。每次先做并丢弃10个warmup更新，再在计时内重新零初始化并重新setup，不复用优化状态或分解；“冷”指优化器状态，不表示清空CPU缓存。

统一计时从零β与初始证书前开始，包含每方法setup、主循环、有限性检查、状态快照和在线诊断。加载/校验数据、参考计算、warmup、预测/支撑指标、写盘和作图在计时外。trace每步诊断；timing每5步诊断，初始/强制末点必查。运行时间等于末点评价后的elapsed，setup+solve=runtime。

单线程环境变量在NumPy/SciPy导入前设为1，并使用threadpool_limits(1)。本Mac Accelerate未向threadpoolctl暴露活动线程池，故准确表述为“已请求单线程并记录环境”，不能说“实测线程数为1”。完整真实环境见 `supplement/environment.json`。

## 为什么迭代数不能直接等价为成本

| 方法 | setup主要成本 | 一次外层主要成本 | 共同证书另需 |
|---|---|---|---|
| ISTA/FISTA | O(nd²+d³) Gram与谱值，O(d²)临时存储 | O(nd)两次matvec；FISTA另有动量 | O(nd) |
| CD | O(nd)列范数 | O(nd)，但Python逐d列；每10轮刷新残差 | O(nd) |
| ADMM | O(nd²+d³) Gram与Cholesky，O(d²)存储 | O(d²)三角求解与向量更新 | O(nd) |

这些是本次实现边界内的稠密运算描述，不是从3个维度点拟合出的渐近复杂度。ISTA/FISTA谱值setup是协议固定实现选择；ADMM不计时外预分解；CD没有单独启用Numba/Cython。

## 统计与外推限制

- 每配置3个timing是同一确定性数据问题的计时重复，不是3份独立训练集。均值±标准差使用样本标准差（ddof=1），并同时保留中位数、min/max；它们不是置信区间。
- 两个同机问题不足以概括所有LASSO问题。FISTA的O(1/k²)理论目标上界不保证每个有限容差例子都比ISTA更早停止或耗时更少。FISTA目标可非单调，trace和timing也可能跨过不同的首次gap阈值。
- 合成只使用一组master与固定相关性/噪声；维度实验仅100/200/400，增加的是无直接真系数的列。没有额外seed、phi=.9或不同样本数的稳健性实验。
- ADMM固定ρ=1、无adaptive rho、无over-relaxation；没有完成ρ=.1/1/10敏感性试验，不能声称ρ最优。
- E06/E10在β=0初始认证结束，不执行求解器setup，必须从算法加速比排名排除。
- 这些是CPU/稠密Python实现；不能外推为所有库、硬件、规模或稀疏矩阵的普遍排名。LASSO一般不保证系数唯一，也不能无条件宣称强凸或线性收敛。
- 原始host之间的wall-clock不能直接排序。新增同机只有32次，不是协议12问题×4方法×4模式重复的正式192次同机完成声明。
