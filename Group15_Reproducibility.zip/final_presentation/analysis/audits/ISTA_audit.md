# ISTA submission audit

## Audit conclusion

The ZIP contains a real, implemented constant-step ISTA solver and one complete local development campaign, `dev-20261024-ista-local01`. It supplies 48 measured runs: 12 traces and 36 timing repeats. All 48 saved coefficient vectors independently recertify as valid and converged at the prescribed relative primal–dual gap tolerance. No optimizer or experiment was rerun for this audit.

Every array in all four datasets is exactly equal to the corresponding ADMM `dev_assets` array; all four NPZ file hashes also agree. All twelve actual lambda values agree exactly, including the fixed S200 anchor used for E11/E12. The twelve high-precision reference beta arrays also agree exactly with ADMM. These facts support a numerical four-method comparison. They do not make the separately measured development runtimes comparable as a fair speed ranking.

Extraction was confined to this audit directory. Path traversal, absolute paths, backslash paths, and symbolic links were rejected by the extractor; no such entries occurred. It extracted 233 files and skipped 92 metadata/Git/cache/environment entries. The original ZIP and submitted sources/results are unchanged.

## Actual implementation

Objective: P(beta) = ||X beta − y||²/(2n) + lambda ||beta||₁. There is no separately fitted intercept, L2 penalty, sample weighting, or positivity constraint.

One update is `beta_next = soft(beta − X.T @ (X @ beta − y)/(n L), lambda/L)`, where `soft(v,tau) = sign(v) maximum(abs(v)−tau,0)`. Initialization forms `G = X.T @ X / n`, uses `scipy.linalg.eigvalsh(G, subset_by_index=[d−1,d−1])`, takes `L = (1+1e−12) lambda_max(G)`, and discards G. Each subsequent gradient uses X and X.T; it does not use a Gram-gradient shortcut. The implementation uses no packaged LASSO optimizer to perform its iteration, momentum, backtracking, screening, or warm start. All saved run configurations specify zero initialization.

An outer iteration is one complete proximal-gradient update, and `gradient_evaluations` equals that update count. Dense iteration cost is O(nd); explicit Gram/spectral setup costs O(nd²+d³) with O(d²) temporary storage. For convex composite LASSO and a valid gradient Lipschitz upper bound, the standard ISTA guarantee is O(1/k) objective suboptimality. This is not a claim that all these LASSO instances are strongly convex or that elapsed runtime follows the same bound.

## Data and configuration

All training predictors use training-only mean and population standard deviation (`ddof=0`); scales below 1e−12 become 1. Response y is centered by the training mean and is not divided by its standard deviation. Test predictors and response use those same training statistics. The loader verifies frozen hashes and makes X Fortran-contiguous float64 before timed optimization. Predictions restore original response units with `y_mean + X_test @ beta`.

Actual data sources/seeds match the protocol: Diabetes is `load_diabetes(scaled=False)` with 442 samples split 353/89. Synthetic data have one 1250×400 AR(1) master with phi=0.3, 10 signal variables among the first 100, coefficients ±2, noise standard deviation 1; S100/S200/S400 take the first 100/200/400 columns with the same response. X seed=2101, support/sign seed=2102, noise seed=2103. Each uses an explicit PCG64 generator. Split seed=20261021; recomputed PCG64 permutations match every saved train/test index exactly. Synthetic support is [1,2,13,27,34,47,69,80,96,98].

All four datasets have finite arrays, disjoint training/test indices, centered training predictors/response, and unit training feature variances within the protocol tolerance. `ISTA_audit.json` records every array shape, dtype, canonical C-byte SHA-256, comparison hash, exact-equality flag, and max absolute difference (all zero) against ADMM.

| Dataset | Training shape | Test n | Dataset NPZ SHA-256 |
|---|---:|---:|---|
| DIA | 353×10 | 89 | `be0177ab9e12fbd6275ce6094ab392f50d59f89df9bcac61b3071eb2db74b1b8` |
| S100 | 1000×100 | 250 | `3f4491980f7de86c5257b26fee1b683082be2577dfdd97f7ccfa26c5608e8dcf` |
| S200 | 1000×200 | 250 | `2b0e25f090d569c5cc84c83a0713be10d8019081a2d594e92657a9252adb2787` |
| S400 | 1000×400 | 250 | `18ac7734450eafc5f25dd282a285c160c3579ffc840619569a2fbdde3c323c4e` |

The 12 unique configurations use 10,000 maximum updates, relative gap tolerance 1e−6, and 10/20/30/45-second limits for DIA/S100/S200/S400. DIA and S200 use the fixed ratios 0.01,0.03,0.10,0.30,1.00. E11/E12 retain absolute lambda=0.22281994907926272, the E02 value. Three timing repeats are repeated measurements of one deterministic problem, not three independent datasets.

## Stopping, timing and provenance

The independent evaluator rebuilds `r=y−X beta`, chooses `theta=(r/n)/(max(1,||X.T@(r/n)||inf/lambda)*(1+1e−14))`, and calculates `D=y.T theta−n||theta||²/2`, `G=P−D`, and `S=max(||y||²/(2n),1e−12)`. Stopping requires a finite valid certificate with G/S≤1e−6 and relative dual-feasibility violation≤1e−12; tiny negative gaps down to −1e−12 S are preserved and treated as zero only for the stop test. Actual-zero KKT branches use `beta != 0`. Support counts instead use the prescribed dataset threshold `1e−6 max(1,y_rms)` and do not modify beta.

Each trace checks after every complete update. Timing checks at multiples of five, plus initial and forced final evaluations. All 3,547 supplied checkpoints match that cadence exactly, have a unique terminal row, retain positive initial timestamps, have nondecreasing elapsed times, and agree with summary metrics at the final point. The initial lambda_max zero-solution cases E06/E10 stop before Gram/eigenvalue setup with zero updates and zero solve seconds.

The timer starts before allocating zero beta and the initial evaluator. Setup includes that initial certificate, state allocation, Gram construction, and eigenvalue calculation. Runtime includes loop work and online objective/dual/KKT checks. File loading, hash checks, shared F-order conversion, reference loading, warmup, predictive/support metrics, output I/O and plots are outside runtime. Warmup executes and discards ten updates per dataset. Standalone job order is all twelve traces followed by three rounds of twelve timing runs; it does not implement four-algorithm rotated order because the campaign contains only ISTA.

All 48 config source hashes match the extracted actual solver, runner and metrics sources. The package reports 1,166/1,166 validation checks and 10/10 unit tests passed. This audit inspected those saved reports rather than presenting them as newly executed tests. Its own independent saved-model audit recalculated objective, primal–dual gap, feasibility, KKT, original-unit train/test RMSE, nonzero count, sparsity ratio, synthetic support precision/recall/F1, and relative coefficient error. All fields match CSV values within the protocol tolerance; the largest absolute numeric difference is 2.7284841053187847e−12. Saved raw coefficients and intercepts also reconstruct correctly.

## Saved numerical results

| ID | Data | λ/λmax | Trace updates | Final relative gap | Local timing median (ms) | Test RMSE | Nonzeros | Support F1 |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| E01 | DIA | 0.1 | 98 | 9.67599e-07 | 3.556 | 56.3652 | 7 | — |
| E02 | S200 | 0.1 | 49 | 9.55908e-07 | 11.606 | 1.1481 | 10 | 1.000 |
| E03 | DIA | 0.01 | 847 | 9.89924e-07 | 28.402 | 55.3296 | 9 | — |
| E04 | DIA | 0.03 | 836 | 9.91566e-07 | 26.692 | 54.9888 | 9 | — |
| E05 | DIA | 0.3 | 70 | 9.26193e-07 | 2.838 | 61.7566 | 4 | — |
| E06 | DIA | 1 | 0 | -4.78465e-16 | 0.148 | 83.0819 | 0 | — |
| E07 | S200 | 0.01 | 75 | 9.29117e-07 | 15.700 | 0.9987 | 97 | 0.187 |
| E08 | S200 | 0.03 | 55 | 9.27227e-07 | 10.669 | 0.9828 | 21 | 0.645 |
| E09 | S200 | 0.3 | 46 | 7.99321e-07 | 12.393 | 2.2904 | 10 | 1.000 |
| E10 | S200 | 1 | 0 | -7.40902e-16 | 0.457 | 5.9519 | 0 | 0.000 |
| E11 | S100 | 0.1 | 42 | 8.87906e-07 | 5.273 | 1.1481 | 10 | 1.000 |
| E12 | S400 | 0.1 | 61 | 7.99566e-07 | 40.865 | 1.1481 | 10 | 1.000 |

All twelve recorded ISTA trace primal-objective sequences are nonincreasing: maximum positive one-step increase is zero at CSV precision. The relative primal–dual gap need not be monotone. Weak DIA penalties take 847/836 trace updates (E03/E04), versus 98 at the 0.10 ratio (E01). This is a measured instance-specific difference, not an asymptotic-rate proof.

S200 illustrates different goals: the 0.03 ratio has 21 selected variables, F1≈0.645 and RMSE≈0.983; 0.10 recovers the 10 true variables with F1=1 but RMSE≈1.148. The fixed lambda grid was not chosen by testing RMSE. Scaling d=100→200→400 keeps response and absolute lambda fixed; local timing medians 5.273→11.606→40.865 ms include both spectral setup and solve. These values describe this submission’s host only.

## Fairness limits and source robustness

Environment: Intel Xeon Platinum 8573C; Linux x86_64; Python3.13.5; NumPy2.3.5, SciPy1.17.0, scikit-learn1.8.0, pandas2.2.3, matplotlib3.10.8, threadpoolctl3.6.0. The recorded OpenBLAS backends both observe one thread. This differs from the protocol formal Python3.12.x and from the ADMM machine/campaign. The package explicitly labels its output as development results. Fair cross-method runtime ranking or speedup claims require one shared-host, shared-runner rerun. Existing native-iteration curves can be compared with clear per-update cost labels; existing local elapsed-time curves may be displayed only as separately hosted measurements.

No failure appears in the supplied 48 runs. Two static robustness limits remain: (1) the solver commits beta and increments its gradient counter before checking finiteness, while the runner restores only its last certified beta on exception rather than the full solver state, so returned state diagnostics could describe a failed attempt; (2) the failure handler’s reevaluation is not guarded by a nested try, so a persistent evaluator failure could escape the wrapper. These do not invalidate the independently checked saved successful results and should not be described as observed experiment failures.

## Reusable source and result locations

- Solver: [member_A_ISTA/solver.py](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/extracted/lasso_A/member_A_ISTA/solver.py)
- Runner: [common/runner.py](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/extracted/lasso_A/common/runner.py)
- Independent metrics: [common/metrics.py](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/extracted/lasso_A/common/metrics.py)
- Actual run serialization/timing: [common/campaign.py](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/extracted/lasso_A/common/campaign.py)
- Data generator specification: [prepare_datasets.py](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/extracted/lasso_A/prepare_datasets.py)
- Frozen experiments: [configs/experiments.json](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/extracted/lasso_A/configs/experiments.json)
- Member report: [member_A_ISTA/analysis.md](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/extracted/lasso_A/member_A_ISTA/analysis.md)
- Member slides/notes: [member_A_ISTA/slides.md](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/extracted/lasso_A/member_A_ISTA/slides.md)
- Saved summary: [dev-20261024-ista-local01/summary.csv](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/extracted/lasso_A/member_A_ISTA/results/dev-20261024-ista-local01/summary.csv)
- Full checkpoint CSV: [convergence.csv](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/extracted/lasso_A/member_A_ISTA/results/dev-20261024-ista-local01/convergence.csv)
- All per-run actual configs and coefficients: [dev-20261024-ista-local01/runs](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/extracted/lasso_A/member_A_ISTA/results/dev-20261024-ista-local01/runs)
- Machine-readable audit and exact per-array/model checks: [ISTA_audit.json](/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/ISTA/ISTA_audit.json)
