# Portable audit index

The copied reports retain historical source paths; these do not need to exist on the recipient machine. The active portable evidence is:

- Exact four solvers: `../../reproduce/inputs/solvers/`
- Exact shared runner/evaluator: `../../reproduce/library/common/`
- Frozen common arrays/configs/references: `../../reproduce/inputs/dev_assets/`
- Original byte-preserved CSVs, configurations, models and environments: `../source_data/`
- New same-machine campaign: `../supplement/`
- Independent recomputation of every saved model: `../model_recomputation.json`

`index.json`, `../source_data/source_catalog.json` and `../../reproduce/input_manifest.json` retain SHA-256 identities. No extracted participant environment, .git directory, or old figure folder is needed to reproduce the numeric integration.
