# FISTA 提交包独立审计

审计范围：仅读源码、文件一致性和已保存模型的独立重算；没有重跑求解器或实验。原始 `lasso_B.zip` 保持不变。

## 结论

可采用其已有数值结果和迭代轨迹。48/48 份最终模型均通过根项目公共证书 `gap/S≤1e-6`，保存的目标、RMSE、稀疏度、支撑指标与独立重算一致；1883 个轨迹检查点的次数、顺序、末点和计时恒等式均通过。12 份参考值独立认证最坏相对 gap 为 `5.327e-14`，无失败运行或 `error.json`。

四个数据集的每个数组均与 ADMM `dev_assets/` **逐元素完全相同**，四个 NPZ 的字节 SHA-256 也相同；E01–E12 的数据/λ/预算/容差相符。不能仅凭文件名判断等同，本审计实际比较了全部数组。

这仍是 `dev-20261023-fista-local01` 开发批次：Apple M4、10 核、24 GiB，Python 3.12.2，六个库版本符合协议。ADMM 原有结果来自另一台 M2；不能把这些本地时间拼成四算法正式速度排名。

## 源码与计算口径

- `member_B_FISTA/solver.py:25`：每次初始化形成 Gram，计算最大特征值，取 `L=(1+1e-12)*lambda_max(Gram)`，没有跨运行复用。
- `member_B_FISTA/solver.py:41`：在外推点 v 计算 `X.T@(X@v-y)/n`，软阈值更新 β，标准 t 动量；公开返回 β，不返回外推点。无重启/回溯/筛选/暖启动。
- `common/runner.py:14`：计时从零向量创建前开始，包括初始证书、谱值 setup、迭代和在线证书；数据读入、参考计算、预测指标、写盘在计时外。
- `common/runner.py:52`：trace 每次更新检查；timing 每5次检查并强制末点。两种模式可能停在不同迭代，E01为71对105，不能混用。
- `common/metrics.py` 与协议附录 B 公式一致，保留带符号目标差与通用 gap，独立对偶可行性检查。
- `prepare_datasets.py`：训练集 z-score（ddof=0），y仅中心化；Diabetes scaled=False；PCG64 seed 2101/2102/2103，split20261021；合成共用400列master。

## 可用于图表的现有结果

| 配置 | 数据 | trace更新数 | 相对gap | 测试RMSE | 非零数 | 本地timing中位数(ms) |
|---|---|---:|---:|---:|---:|---:|
| E01 | DIA | 71 | 2.823e-07 | 56.365343 | 7 | 2.1748 |
| E02 | S200 | 56 | 5.552e-07 | 1.148070 | 10 | 3.0403 |
| E03 | DIA | 318 | 2.910e-07 | 55.329673 | 9 | 7.0211 |
| E04 | DIA | 266 | 7.628e-07 | 54.988800 | 9 | 6.2945 |
| E05 | DIA | 70 | 3.816e-07 | 61.756769 | 4 | 1.4878 |
| E06 | DIA | 0 | 4.785e-16 | 83.081882 | 0 | 0.0465 |
| E07 | S200 | 86 | 8.245e-07 | 0.998662 | 97 | 4.0186 |
| E08 | S200 | 65 | 8.265e-07 | 0.982777 | 21 | 3.0780 |
| E09 | S200 | 43 | 4.559e-07 | 2.290398 | 10 | 2.9144 |
| E10 | S200 | 0 | 3.705e-16 | 5.951945 | 0 | 0.0859 |
| E11 | S100 | 46 | 8.447e-07 | 1.148072 | 10 | 1.8701 |
| E12 | S400 | 67 | 8.619e-07 | 1.148070 | 10 | 7.5452 |

这些时间只说明该 M4 开发机器本地情况。E06/E10 是初始零解边界，均零次更新，不能用于加速比排名。FISTA 轨迹有非单调目标段是标准动量方法允许的现象：E01最大单步上升约0.03875，E02约0.003224。

## 限制与需要说明的问题

- **F01 / blocking-formal-comparison**：Local Apple M4 campaign; cannot rank speed against other machines. 证据：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/member_B_FISTA/results/dev-20261023-fista-local01/environment.json`。
- **F02 / provenance**：git_commit is null in environment and all configs; clean frozen commit is not established. 证据：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/member_B_FISTA/results/dev-20261023-fista-local01/environment.json`。
- **F03 / environment-verification**：threadpoolctl observed=[] and blas_backend=[]; thread environment variables are 1 but actual BLAS worker count is unverified. np.show_config reports Apple Accelerate. 证据：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/member_B_FISTA/results/dev-20261023-fista-local01/environment.json`。
- **F04 / formal-data-provenance**：Archive includes locally generated datasets_v1.zip and a freeze script, but no independent evidence this is the group-authorized published byte package. Campaign explicitly dev-. 证据：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/freeze_data.py`。
- **F05 / identity-limit**：common_source_sha256 covers runner.py and metrics.py only, not campaign/data/environment/schema code. Submitted files retained and independently indexed by extraction manifest. 证据：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/common/campaign.py`。
- **F06 / reference-provenance-limit**：Reference environment records Python, sklearn and threadpool_info only; complete CPU/OS/NumPy/SciPy metadata is not present in each reference. Independent certificate checks remain valid. 证据：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/build_references.py`。
- **F07 / trace-audit-limit**：Intermediate checkpoints contain metrics but no saved beta. Formula and structural checks plus independent final recomputation support use; full trajectory numerical regeneration has not been run. 证据：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/member_B_FISTA/results/dev-20261023-fista-local01/convergence.csv`。
- **F08 / interpretation**：FISTA permits objective increases: nonmonotonic trace segments are expected and should not be mislabeled as failure. 证据：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/member_B_FISTA/tests/test_report.json`。
- **F09 / duplicate-outputs**：merged_results repeats member result files byte-for-byte; count 48 source runs once, not 96. 证据：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/merged_results/dev-20261023-fista-local01`。
- **F10 / interpretation**：trace checks every update and timing every five updates. Nonmonotone certificate crossings mean timing can need substantially more iterations (E01 trace71 vs timing105); these counts are not interchangeable. 证据：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/member_B_FISTA/results/dev-20261023-fista-local01/summary.csv`。

提交包自带8项测试全部通过的报告；本次没有运行其测试，只把它作为提交证据保留。独立审计以保存模型重算为主要证据。其 `source_manifest.json` 所列18个源文件SHA-256均与提交文件一致。

## 快速路径

- 源码根：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B`
- summary：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/member_B_FISTA/results/dev-20261023-fista-local01/summary.csv`
- convergence（含 E01/E02 trace）：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/member_B_FISTA/results/dev-20261023-fista-local01/convergence.csv`
- 模型/config：`/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/FISTA/lasso_B/member_B_FISTA/results/dev-20261023-fista-local01/runs/<run_id>/`
- 机器可读审计：`final_presentation/_audit/FISTA_audit.json`
- 可重做的只读审计脚本：`final_presentation/_audit/FISTA/audit_checks.py`
- 安全解压逐文件清单：`final_presentation/_audit/FISTA/extraction_manifest.json`

静态失败路径补充（未在48份成功记录中发生）：FISTA在有限性检查前提交β/v/t；旧runner出错后仅恢复最后认证β，没有恢复完整state，故失败时state diagnostics可能对应坏更新；其恢复评价若持续报错也可能逃出异常包装。该限制不否定已核验的成功模型，新同机补充使用具有状态快照/恢复逻辑的公共runner。
