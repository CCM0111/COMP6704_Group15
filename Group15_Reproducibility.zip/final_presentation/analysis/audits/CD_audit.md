# Coordinate Descent archive audit

Archive: `/Users/lhm/Desktop/tmp/lasso_project/lasso_project_CD.zip`  
SHA-256: `8e7bf1fe223bbf236c9330bfdef7c2bc7c749f927d4846f56324b0925d53374c`  
Extracted source: `/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/CD/lasso_project`  
Campaign: `dev-20261023-cd-local01`

This audit only read source, configuration, saved coefficients, references and logs. It ran no optimization experiments and changed no archived source files.

## Findings

- Saved-artifact numerical checks: **PASS**. There are 48 unique runs (12 trace + 36 timing), 530 checkpoints, and 48 recorded converged runs.
- The core CD implementation matches the normalized LASSO objective. It uses cyclic exact coordinate minimization, incremental residuals and a full residual refresh every 10 sweeps; each outer step is one complete sweep.
- Every stored array in DIA, S100, S200 and S400 is byte-for-byte identical to the ADMM development assets. Maximum absolute array difference is 0; NPZ SHA-256 values also match. All 48 problem IDs, config IDs, dataset hashes and lambda values match the corresponding ADMM runs.
- All 48 saved models were independently re-evaluated with the root evaluator, including the signed objective/reference gap, primal-dual certificate, KKT residual, train/test RMSE, nonzero count, support scores and original coefficient/intercept recovery.
- All 12 numerical references pass the independently recomputed relative primal-dual gap threshold of 1e-10.
- Timings include the initial certificate, column-norm setup, coordinate sweeps, residual refresh and online diagnostics. Loading, model output and prediction metrics stay outside the timer. Trace checks every sweep; timing checks every 5 sweeps, with a forced final check.

## Comparability limits

- Archived timings come from a separate Apple M2 host; do not rank them against another member's host timings.
- Campaign is explicitly dev-; git_commit is null and threadpoolctl observed[]/blas_backend[] do not verify an active BLAS threadpool. NumPy config reports Accelerate; all five thread environment variables are recorded as 1.
- Reference NPZ schema is an archived dialect: gap and reference_environment keys; no experiment_id scalar. The mathematical certificate is independently rechecked below.
- Archived CD runner imports CD directly and is not an interchangeable four-algorithm public runner. Its solver state API can be integrated into one common runner without changing core updates.

CD host: Apple M2, 8 physical/logical cores, 16 GiB RAM, macOS 14.6.1, Python 3.12.6. The six required package versions match the protocol lock. Environment ID: `ee3a0d73b77c3340f86e2ad2e3406d7b750128f61a74bcdc82ea6a173b5a5761`.

## Actual saved results

These are archived development results from the CD host; millisecond timings cannot support a cross-host algorithm ranking.

| Experiment | Dataset | Lambda ratio | Trace sweeps | Relative PD gap | Test RMSE | Nonzeros | F1 | Timing median [min,max] ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| E01 | DIA | 0.1 | 16 | 8.51114e-07 | 56.3653 | 7 | — | 0.81375 [0.813166, 0.814625] |
| E02 | S200 | 0.1 | 8 | 4.46995e-07 | 1.14807 | 10 | 1 | 9.92796 [9.64237, 9.9965] |
| E03 | DIA | 0.01 | 105 | 9.01364e-07 | 55.3296 | 9 | — | 3.80492 [3.72421, 3.84492] |
| E04 | DIA | 0.03 | 107 | 9.91809e-07 | 54.9888 | 9 | — | 3.89333 [3.85629, 3.99492] |
| E05 | DIA | 0.3 | 11 | 9.39582e-07 | 61.7568 | 4 | — | 0.637083 [0.626167, 0.642542] |
| E06 | DIA | 1 | 0 | 4.78465e-16 | 83.0819 | 0 | — | 0.063083 [0.049, 0.064042] |
| E07 | S200 | 0.01 | 13 | 5.27258e-07 | 0.998663 | 97 | 0.186916 | 14.7024 [14.6973, 15.0229] |
| E08 | S200 | 0.03 | 10 | 3.50597e-07 | 0.982777 | 21 | 0.645161 | 9.6685 [9.45913, 10.643] |
| E09 | S200 | 0.3 | 7 | 7.42879e-07 | 2.2904 | 10 | 1 | 9.93863 [9.4795, 10.1451] |
| E10 | S200 | 1 | 0 | 3.70451e-16 | 5.95194 | 0 | 0 | 0.132125 [0.127083, 0.137792] |
| E11 | S100 | 0.1 | 8 | 4.46995e-07 | 1.14807 | 10 | 1 | 5.42317 [5.27225, 5.46754] |
| E12 | S400 | 0.1 | 8 | 4.46995e-07 | 1.14807 | 10 | 1 | 18.2093 [18.0914, 18.2588] |

## Recomputed evidence

Maximum absolute recorded-versus-recomputed differences across 48 models:

| Field | Maximum absolute difference |
|---|---:|
| train_rmse | 0 |
| test_rmse | 0 |
| nonzero_count | 0 |
| sparsity_ratio | 0 |
| duality_gap | 0 |
| relative_duality_gap | 0 |
| dual_feasibility_violation | 0 |
| kkt_violation | 0 |
| final_objective | 0 |
| objective_gap | 0 |
| relative_objective_gap | 0 |
| support_precision | 0 |
| support_recall | 0 |
| support_f1 | 0 |
| coef_relative_error | 0 |

Source evidence:

- `/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/CD/lasso_project/member_C_CD/solver.py:25`
- `/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/CD/lasso_project/member_C_CD/solver.py:40`
- `/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/CD/lasso_project/common/runner.py:14`
- `/Users/lhm/Desktop/tmp/lasso_project/final_presentation/_audit/CD/lasso_project/common/campaign.py:63`

A saved test report says 7 source tests passed; this audit did not rerun those tests. The archive's own validation report also says 48/48 passed. Independent saved-model and metadata checks above provide separate verification.

Use verified core solver for a new same-host common-runner campaign. Archived convergence/model results are valid development evidence; retain archive host labels for any archived timings. No solver reruns performed in this audit.
