# Integration Audit

本次先审计三个 ZIP 和现有 ADMM 项目，保持提交源码与原始结果不变；然后用四份原求解器字节拷贝和一个公共 runner，新增 E01/E02 的32次同机补充。审计阶段仅重算保存模型，补充阶段才执行新的优化迭代。

## 文件与来源

| 方法 | 提交来源 | 原批次 | summary 行数 | 可移植原始CSV |
|---|---|---|---|---|
| ISTA | lasso_A_ISTA.zip | dev-20261024-ista-local01 | 48 | analysis/source_data/ISTA/dev-20261024-ista-local01/summary.csv |
| FISTA | lasso_B.zip | dev-20261023-fista-local01 | 48 | analysis/source_data/FISTA/dev-20261023-fista-local01/summary.csv |
| CD | lasso_project_CD.zip | dev-20261023-cd-local01 | 48 | analysis/source_data/CD/dev-20261023-cd-local01/summary.csv |
| ADMM | 原 ADMM 项目（非新 ZIP） | dev-20261022-admm-v3 | 48 | analysis/source_data/ADMM/dev-20261022-admm-v3/summary.csv |

原 CSV 与每次运行的 config、模型、environment、validation report 已按字节保存于 `source_data/`；不复制重复 merged_results 或原有图片。各副本SHA-256及原路径见 `source_data/source_catalog.json`。三个原 ZIP 未修改，其哈希也记录在该清单中。

## 独立核验结果

- 原始 summary 合计192条；新增同机32条；合并共224条、7721个唯一轨迹检查点。224条均记录收敛，保存系数独立重算也全部通过，无未达精度的运行被隐藏。
- 三份成员审计逐数组对照确认：DIA/S100/S200/S400 的训练/测试特征、响应、原始响应、训练统计量、行号和合成真值与 ADMM 开发输入完全相同；NPZ SHA-256也相同。
- 冻结12配置的实际λ相同，E11/E12复制E02的绝对λ。参考解均经独立证书认证；参考目标是高精度数值参考值，未称为已知精确最优值。
- 所有224份保存β在共有数组上重算目标、通用primal-dual gap、对偶可行性、KKT、原单位RMSE、稀疏度和支撑指标。结果见 `model_recomputation.json`，没有重跑192条原实验来代替提交证据。
- 新增32次包括每次运行的实际 config、模型、真实环境、源码身份、顺序和独立检查：`supplement/verification_report.json`。
- 每个原包自己的单元测试报告保留为历史证据；本次未把它们冒充为新执行的测试。ADMM原验证报告明确 `formal_comparison_complete=false`。

## 原实现与统一接入

| 方法 | 保持的主参数 | 一次外层更新 |
|---|---|---|
| ISTA | L=Gram最大特征值×(1+1e-12)，无回溯/筛选/暖启动 | 一次完整近端梯度更新 |
| FISTA | 同样L；t0=1；无重启/回溯/筛选/暖启动 | 近端梯度+标准动量；报告β而非外推点 |
| CD | cyclic，10 sweeps刷新一次残差，无筛选 | 按固定列顺序完成一轮d个坐标 |
| ADMM | ρ=1，relaxation=1，无adaptive rho，Cholesky求解；eps_rel=1e-4 | 一次x/z/u完整更新，返回z |

求解器源均按原字节复制到 `../reproduce/inputs/solvers/`，只用 importlib 的独立模块名加载；没有更改公式、梯度缓存方式、参数或阈值。适配仅向各实现传入其严格要求的配置键。统一runner/evaluator等精确快照位于 `../reproduce/library/common/`。输入与库哈希见 `../reproduce/input_manifest.json`，实际运行身份见 `supplement/source_identities.json`。

## 合并约定

`Merged_Results.csv` 保留协议55列，`Convergence_Results.csv` 保留协议29列；都追加 `owner,evidence_scope,source_file,source_sha256,environment_file,host_label`。

`evidence_scope=original` 恰好192条；`same_machine_supplement` 恰好32条。`source_sha256` 是对应不可变主CSV文件字节哈希。合并CSV中的模型/config/environment路径相对于 `final_presentation/`；原始CSV保持原有相对路径，使用其所在campaign目录解释。Supplemental主CSV的自身哈希单元格为空，避免自指哈希；它们的实际哈希记录在验证报告，且已经填入合并派生CSV。

## 证据边界

原包来自多台机器，ISTA原Python为3.13.5；部分包git_commit为空。Mac的threadpoolctl返回空列表，环境变量记录单线程请求但没有观测到实际BLAS工作线程数；NumPy构建配置报告Accelerate。新增同机补充同样保留这一限制。全部结果均不能宣称是共同冻结commit上的完整正式192次同机比较。

可移植审计索引：`audits/README.md`。统计与解释边界见 `Experiment_Comparability.md`，可引用结果见 `Results_Summary.md`。
