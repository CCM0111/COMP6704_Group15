#!/usr/bin/env python3
"""Sequential 32-run, same-machine E01/E02 supplement using exact solver copies.

This is a focused integration supplement, not the formal 192-run protocol grid.
Use a new --output directory when reproducing; existing evidence is preserved.
"""
from __future__ import annotations
import os,sys
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
if os.environ.get('PYTHONHASHSEED')!='0':
    os.environ['PYTHONHASHSEED']='0';os.execv(sys.executable,[sys.executable,*sys.argv])
import argparse,csv,importlib.util,json,statistics
from datetime import datetime,timezone
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
LIBRARY=BASE/'reproduce/library'
sys.path.insert(0,str(LIBRARY))
import numpy as np
from threadpoolctl import threadpool_limits
from common.data import canonical_hash,sha256_file,load_problem
from common.environment import capture_environment,enforce_formal_environment
from common.metrics import certify,original_unit_metrics
from common.runner import run_one,warmup
from common.schemas import SUMMARY_COLUMNS,CONVERGENCE_COLUMNS,cell

CAMPAIGN='integration-20261025-core'
ALGORITHMS=['ISTA','FISTA','CD','ADMM']
OWNER={'ISTA':'Member A','FISTA':'Member B','CD':'Member C','ADMM':'Member D'}
EXTRA=['owner','evidence_scope','source_file','source_sha256','environment_file','host_label']


def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


def write_csv(path,columns,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,columns,lineterminator='\n');writer.writeheader()
        for row in rows:writer.writerow({k:cell(row.get(k)) for k in columns})


def load_solver(name):
    path=BASE/'reproduce/inputs/solvers'/f'{name}.py'
    module_name=f'frozen_supplement_{name.lower()}'
    spec=importlib.util.spec_from_file_location(module_name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[module_name]=module;spec.loader.exec_module(module)
    return module


def parameters(name,manifest):
    if name=='ISTA':return dict(L_method='gram_eigvalsh',restart=False,backtracking=False)
    if name=='FISTA':return dict(L_method='gram_eigvalsh',restart=False,backtracking=False,t_initial=1.0)
    if name=='CD':return dict(selection='cyclic',refresh_every_sweeps=10,screening=False)
    return dict(rho=1.0,relaxation=1.0,adaptive_rho=False,linear_solver='scipy_cho_solve',eps_abs=manifest['nz_threshold'],eps_rel=1e-4)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',default='analysis/supplement-rerun',help='New directory relative to final_presentation')
    args=parser.parse_args();out=(BASE/args.output).resolve()
    if not out.is_relative_to(BASE):raise ValueError('Output must stay inside the portable presentation directory')
    if out.exists():raise FileExistsError(f'Preserving existing evidence: {out}. Choose a new --output directory.')
    manifest=json.loads((BASE/'reproduce/input_manifest.json').read_text())
    for entry in manifest['files']:
        if sha256_file(BASE/entry['portable_file'])!=entry['sha256']:
            raise ValueError('Frozen source/input hash mismatch: '+entry['portable_file'])
    out.mkdir(parents=True)
    solvers={name:load_solver(name) for name in ALGORITHMS}
    problems={eid:load_problem(BASE/'reproduce/inputs',eid,development=True) for eid in ('E01','E02')}
    source_hashes={name:sha256_file(BASE/'reproduce/inputs/solvers'/f'{name}.py') for name in ALGORITHMS}
    shared_files={p.name:sha256_file(p) for p in sorted((LIBRARY/'common').glob('*.py'))}
    shared_hash=canonical_hash(shared_files)
    identities=dict(solver_sha256=source_hashes,shared_library_sha256=shared_hash,shared_library_files=shared_files,
        run_comparison_source_sha256=sha256_file(__file__),input_manifest_sha256=sha256_file(BASE/'reproduce/input_manifest.json'))
    dump(out/'source_identities.json',identities)
    rows=[];history=[];verification=[];execution_order=[]
    with threadpool_limits(limits=1):
        environment=capture_environment(BASE,git_commit='unversioned-supplement')
        # Enforce package/Python lock and configured thread limits; actual pool
        # information is recorded even when Accelerate is not observable.
        enforce_formal_environment(environment)
        environment['evidence_scope']='same_machine_supplement'
        environment['campaign_id']=CAMPAIGN
        environment['threadpool_observability']='observed' if environment['threads']['observed'] else 'not exposed by threadpoolctl; limits requested via environment'
        dump(out/'environment.json',environment)
        for repeat in range(4):
            mode='trace' if repeat==0 else 'timing'
            for dataset_index,eid in enumerate(('E01','E02')):
                offset=(repeat+dataset_index)%4
                order=ALGORITHMS[offset:]+ALGORITHMS[:offset]
                for name in order:
                    p=problems[eid];e=p['experiment'];m=p['manifest'];solver=solvers[name]
                    params=parameters(name,m);lam=e['lambda_value'];X=p['X'];y=p['y']
                    config=dict(algorithm=name,max_iterations=e['max_iterations'],max_runtime_seconds=e['max_runtime_seconds'],
                        stopping_tolerance=e['stopping_tolerance'],check_every=1 if mode=='trace' else 5,
                        nonzero_threshold=m['nz_threshold'],algorithm_config=params)
                    # Discard at most ten warmup updates, then allocate a new
                    # cold state inside run_one. No factors or solution reuse.
                    warmup(solver,X,y,lam,params)
                    started=datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
                    result=run_one(solver,X,y,lam,config)
                    runid=f'{CAMPAIGN}__{eid}__{name}__{mode}__r{repeat:02}'
                    run=out/'runs'/runid;run.mkdir(parents=True)
                    actual_params=params.copy()
                    if result.state is not None and name in ('ISTA','FISTA'):
                        actual_params.update(L_value=float(result.state.L),step_size=float(result.state.step_size))
                    problem_id=canonical_hash(dict(objective_version='lasso-mean-v1',dataset_sha256=p['dataset_sha256'],
                        train_indices_sha256=m['train_indices_sha256'],test_indices_sha256=m['test_indices_sha256'],
                        lambda_value=lam,preprocessing_version=m['preprocessing_version'],dtype='float64'))
                    config_id=canonical_hash(dict(problem_id=problem_id,experiment_id=eid,protocol_version='1.0.0',mode=mode,
                        max_iterations=e['max_iterations'],max_runtime_seconds=e['max_runtime_seconds'],
                        stopping_tolerance=e['stopping_tolerance'],check_every=config['check_every'],timing_version='cold-inclusive-v1'))
                    implementation_id=canonical_hash(dict(algorithm=name,algorithm_parameters=actual_params,
                        solver_source_sha256=source_hashes[name],common_source_sha256=shared_hash))
                    identity=dict(problem_id=problem_id,config_id=config_id,implementation_id=implementation_id,
                        environment_id=environment['environment_id'],dataset_sha256=p['dataset_sha256'],
                        reference_sha256=p['reference_sha256'],solver_source_sha256=source_hashes[name],common_source_sha256=shared_hash,
                        git_commit='unversioned-supplement')
                    configuration=dict(schema_version='1.0.0',protocol_version='1.0.0',is_example=False,development_only=True,
                        evidence_scope='same_machine_supplement',campaign_id=CAMPAIGN,run_id=runid,experiment_id=eid,algorithm=name,mode=mode,
                        repeat_index=repeat,identity=identity,
                        data=dict(dataset_id=e['dataset_id'],n_train=X.shape[0],n_test=p['X_test'].shape[0],n_features=X.shape[1],
                            split_seed=20261021,preprocessing_version=m['preprocessing_version'],dtype='float64',x_order='F',fit_intercept=False,scale_y=False),
                        problem=dict(objective_version='lasso-mean-v1',**{'lambda':lam},lambda_max=m['lambda_max'],lambda_ratio=e['lambda_ratio'],
                            objective_scale=m['objective_scale'],nonzero_threshold=m['nz_threshold'],reference_objective=p['reference']['P_ref'],
                            reference_duality_gap=p['reference']['reference_duality_gap'],lambda_policy=e['lambda_policy'],anchor_dataset_id=e['anchor_dataset_id']),
                        stopping=dict(relative_duality_gap_tolerance=e['stopping_tolerance'],dual_feasibility_tolerance=1e-12,
                            max_iterations=e['max_iterations'],max_runtime_seconds=e['max_runtime_seconds'],check_every=config['check_every']),
                        initialization=dict(beta='zeros',warm_start=False,reuse_factorization_across_runs=False),algorithm_parameters=actual_params,
                        timing=dict(clock='perf_counter_ns',timing_version='cold-inclusive-v1',include_diagnostics=True,include_setup=True,include_io=False,
                            blas_threads=1,execution_order_index=len(rows),timestamp_start_utc=started,warmup_updates=10,
                            order_policy='rotate ISTA,FISTA,CD,ADMM by repeat+dataset_index; all runs sequential'),
                        paths=dict(dataset_file=str((BASE/'reproduce/inputs/dev_assets'/p['dataset_file'].removeprefix('dev_assets/')).relative_to(BASE)),
                            reference_file=str((BASE/'reproduce/inputs/dev_assets'/p['reference_file'].removeprefix('dev_assets/')).relative_to(BASE)),
                            environment_file=str((out/'environment.json').relative_to(BASE)),root_kind='presentation_relative'))
                    dump(run/'config.json',configuration)
                    final=result.metrics or {};beta=result.beta
                    if beta is not None:
                        coef=beta/p['x_scale'];intercept=p['y_mean']-p['x_mean']@coef
                        np.savez_compressed(run/'solution.npz',beta=beta,coef_raw=coef,intercept_raw=np.float64(intercept),
                            lambda_value=np.float64(lam),run_id=np.str_(runid),dataset_sha256=np.str_(p['dataset_sha256']),development_only=np.bool_(True))
                        independent=certify(X,y,beta,lam)
                        predictive=original_unit_metrics(X,p['X_test'],p['y_train_raw'],p['y_test_raw'],p['y_mean'],beta,m['nz_threshold'],p['beta_true_std'])
                        objective_gap=independent['objective_value']-p['reference']['P_ref']
                        checked=bool(independent['valid'] and all(np.isclose(independent[k],final[k],rtol=1e-12,atol=1e-12) for k in
                            ('objective_value','duality_gap','relative_duality_gap','dual_feasibility_violation','kkt_violation'))
                            and objective_gap>=-5e-10*m['objective_scale'])
                        verification.append(dict(run_id=runid,passed=checked,independent_certificate=independent,independent_predictive_metrics=predictive,
                            objective_gap=objective_gap,relative_objective_gap=objective_gap/m['objective_scale']))
                    else:
                        independent={};predictive={};objective_gap=None;checked=False
                        verification.append(dict(run_id=runid,passed=False,error='No valid final beta'))
                    row=dict(schema_version='1.0.0',protocol_version='1.0.0',is_example=False,campaign_id=CAMPAIGN,experiment_id=eid,
                        dataset_id=e['dataset_id'],algorithm=name,run_id=runid,mode=mode,repeat_index=repeat,seed=20261021,
                        **{k:identity[k] for k in ('problem_id','config_id','implementation_id','environment_id','dataset_sha256')},
                        n_samples=X.shape[0],n_test_samples=p['X_test'].shape[0],n_features=X.shape[1],**{'lambda':lam},lambda_max=m['lambda_max'],
                        lambda_ratio=e['lambda_ratio'],objective_scale=m['objective_scale'],max_iterations=e['max_iterations'],
                        max_runtime_seconds=e['max_runtime_seconds'],stopping_tolerance=e['stopping_tolerance'],check_every=config['check_every'],
                        iterations=result.iterations,runtime_seconds=result.runtime_seconds,setup_seconds=result.setup_seconds,solve_seconds=result.solve_seconds,
                        time_to_tolerance_seconds=result.runtime_seconds if result.convergence_status=='converged' else None,
                        final_objective=independent.get('objective_value'),reference_objective=p['reference']['P_ref'],objective_gap=objective_gap,
                        relative_objective_gap=None if objective_gap is None else objective_gap/m['objective_scale'],
                        **{k:independent.get(k) for k in ('duality_gap','relative_duality_gap','dual_feasibility_violation','kkt_violation')},
                        **predictive,nonzero_threshold=m['nz_threshold'],convergence_status=result.convergence_status,stop_reason=result.stop_reason,
                        validation_status='pass' if checked and result.error is None else 'fail',
                        config_file=str((run/'config.json').relative_to(BASE)),solution_file=str((run/'solution.npz').relative_to(BASE)) if beta is not None else None,
                        error_file=str((run/'error.json').relative_to(BASE)) if result.error else None,
                        owner=OWNER[name],evidence_scope='same_machine_supplement',source_file=str((out/'Supplemental_Results.csv').relative_to(BASE)),
                        source_sha256=None,environment_file=str((out/'environment.json').relative_to(BASE)),host_label=environment['cpu_model'])
                    if result.error:dump(run/'error.json',dict(run_id=runid,**result.error))
                    rows.append(row)
                    for h in result.history:
                        hg=None if h.get('objective_value') is None else h['objective_value']-p['reference']['P_ref']
                        history.append(dict(schema_version='1.0.0',is_example=False,campaign_id=CAMPAIGN,experiment_id=eid,dataset_id=e['dataset_id'],
                            algorithm=name,run_id=runid,mode=mode,config_id=config_id,**h,objective_gap=hg,
                            relative_objective_gap=None if hg is None else hg/m['objective_scale'],owner=OWNER[name],evidence_scope='same_machine_supplement',
                            source_file=str((out/'Supplemental_Convergence.csv').relative_to(BASE)),source_sha256=None,
                            environment_file=str((out/'environment.json').relative_to(BASE)),host_label=environment['cpu_model']))
                    execution_order.append(dict(index=len(rows)-1,experiment_id=eid,algorithm=name,mode=mode,repeat=repeat))
                    print(eid,name,mode,repeat,result.convergence_status,result.iterations,f'{result.runtime_seconds*1000:.4f}ms',flush=True)
    write_csv(out/'Supplemental_Results.csv',SUMMARY_COLUMNS+EXTRA,rows)
    write_csv(out/'Supplemental_Convergence.csv',CONVERGENCE_COLUMNS+EXTRA,history)
    # A CSV cannot contain its own final byte hash. Source hash cells in these
    # primary CSVs stay blank; the merged derivatives carry their actual hashes.
    verification_report=dict(development_only=True,evidence_scope='same_machine_supplement',campaign_id=CAMPAIGN,
        expected_runs=32,observed_runs=len(rows),all_models_independently_verified=all(v['passed'] for v in verification),
        all_converged=all(r['convergence_status']=='converged' for r in rows),checks=verification,execution_order=execution_order,
        primary_file_hashes={p.name:sha256_file(p) for p in (out/'Supplemental_Results.csv',out/'Supplemental_Convergence.csv')})
    dump(out/'verification_report.json',verification_report)
    if not verification_report['all_models_independently_verified']:raise SystemExit('Independent supplement verification failed')
    print('32-run supplement complete:',out,flush=True)

if __name__=='__main__':main()
