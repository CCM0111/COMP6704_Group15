#!/usr/bin/env python3
"""Rebuild empirical slide figures solely from the final package's merged CSVs.

Usage: python reproduce/make_experiment_figures.py
No optimizer is called and no archived source project is required. Each chart's
CSV hashes, filters, fields, run IDs and factual claims enter plot_sources.json.
"""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for _name in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"]:
    os.environ.setdefault(_name, "1")
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "reproduce/.mplconfig"))
os.environ.setdefault("MPLBACKEND", "Agg")

import argparse
import csv
import hashlib
import json
import math
import statistics
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import SymmetricalLogLocator
import numpy as np


ALGORITHMS = ["ISTA", "FISTA", "CD", "ADMM"]
COLORS = {"ISTA": "#2563eb", "FISTA": "#e87822", "CD": "#118965", "ADMM": "#7a45b0"}
MARKERS = {"ISTA": "o", "FISTA": "s", "CD": "^", "ADMM": "D"}
LINESTYLES = {"ISTA": "-", "FISTA": "--", "CD": "-.", "ADMM": ":"}
FLOOR = 1e-12
TOLERANCE = 1e-6
STYLE = {
    "font.family": "DejaVu Sans", "font.size": 22, "axes.labelsize": 24,
    "axes.titlesize": 23, "xtick.labelsize": 22, "ytick.labelsize": 22,
    "legend.fontsize": 22, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.alpha": .18, "svg.fonttype": "none",
    "pdf.fonttype": 42, "figure.facecolor": "white", "axes.facecolor": "white",
}

SHORT_CAPTIONS = {
    "fig01_convergence_outer": "Original traces · CD update = one full sweep · target 10⁻⁶",
    "fig02_signed_objective_gap": "Original traces · signed reference differences · no absolute-value transform",
    "fig03_objective_values": "Original traces · original LASSO objective · ADMM uses β=z",
    "fig04_fista_oscillation": "Original FISTA E03 · measured increase at updates 44→45",
    "fig05_shared_trace_time_E02": "Same-machine supplement · signed objective gap · cold setup + diagnostics",
    "fig05b_shared_PD_gap_time_E02": "Same-machine supplement · PD certificate · cold setup + diagnostics",
    "fig06_shared_timing_E01_E02": "Same-machine supplement · median + min–max · 3 cold timing runs",
    "fig07_regularization_S200": "Original trace finals · nested markers show near-identical solutions",
    "fig08_regularization_DIA": "Original trace finals · nested markers show near-identical solutions",
    "fig09_within_host_dimension_scaling": "Original timings · different hosts · compare within each panel only",
    "fig10_admm_residuals_and_gap": "Original ADMM E02 · residual pass at 19 · common certificate at 29",
    "fig11_objective_certificate_table": "Original trace finals · objectives shown to 6 significant digits",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        rows = list(reader)
    if not rows or any(None in r or any(v is None for v in r.values()) for r in rows):
        raise ValueError(f"Empty or malformed source CSV: {path}")
    for row in rows:
        if row.get("is_example") != "false":
            raise ValueError("Example data must not enter empirical charts")
    return rows


def number(row: dict, key: str) -> float:
    value = row[key]
    if value in ("", None):
        return math.nan
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"Nonfinite source field: {row.get('run_id')} {key}")
    return value


def select(rows: list[dict], **filters) -> list[dict]:
    return [r for r in rows if all(r[k] == v if not isinstance(v, (list, set, tuple)) else r[k] in v for k, v in filters.items())]


def display_gap(values: np.ndarray) -> np.ndarray:
    if np.any(values < -FLOOR):
        raise ValueError("Materially negative primal-dual gap; audit source rather than plotting abs(gap)")
    return np.maximum(values, FLOOR)


def decorate(ax, xlabel: str, ylabel: str, *, logy: bool = False) -> None:
    ax.set(xlabel=xlabel, ylabel=ylabel)
    if logy:
        ax.set_yscale("log")
    ax.tick_params(axis="both", which="major", pad=6)
    ax.grid(True, which="major", alpha=.2)


def signed_scale(ax, values):
    """Keep signed data without autoscaling an empty negative half-axis."""
    data = np.concatenate([np.asarray(value, dtype=float) for value in values])
    finite = data[np.isfinite(data)]
    ax.set_yscale("symlog", linthresh=1e-12, linscale=.7)
    lower = min(-1.5e-13, float(finite.min())*1.6)
    upper = max(1.5e-12, float(finite.max())*1.4)
    ax.set_ylim(lower, upper)
    locator = SymmetricalLogLocator(base=10, linthresh=1e-12)
    locator.set_params(numticks=8)
    ax.yaxis.set_major_locator(locator)


def shared_legend(fig, ax, *, columns=4):
    handles, labels = ax.get_legend_handles_labels()
    fig.legend(handles, labels, ncol=columns, frameon=False, loc="lower center",
               bbox_to_anchor=(.55, .082), fontsize=22, handlelength=1.6,
               columnspacing=1.15, handletextpad=.55, borderpad=0)


class Charts:
    def __init__(self, summary: Path, convergence: Path, output: Path):
        self.summary_path = summary
        self.convergence_path = convergence
        self.summary = read_csv(summary)
        self.convergence = read_csv(convergence)
        self.output = output
        self.output.mkdir(parents=True, exist_ok=True)
        self.charts = []

    def trace(self, algorithm: str, experiment: str, scope: str = "original") -> tuple[dict, list[dict]]:
        rows = select(self.summary, algorithm=algorithm, experiment_id=experiment, mode="trace", evidence_scope=scope)
        if len(rows) != 1:
            raise ValueError(f"Expected one {scope} {algorithm} {experiment} trace, got {len(rows)}")
        row = rows[0]
        history = sorted(select(self.convergence, run_id=row["run_id"], evidence_scope=scope), key=lambda r: int(r["iteration"]))
        if not history:
            raise ValueError(f"Trace without checkpoints: {row['run_id']}")
        return row, history

    def save(self, fig, stem: str, caption: str, *, scope: str, filters: dict,
             fields: list[str], rows: list[dict], claims: list[str], csv_sources: tuple[str, ...] = ("summary", "convergence")):
        # Leave footer space so data labels do not collide with provenance.
        short_caption = SHORT_CAPTIONS[stem]
        fig.text(.013, .015, short_caption, ha="left", va="bottom", fontsize=20, color="#475569")
        fig.tight_layout(rect=(0, .11, 1, .985), pad=1.1, w_pad=1.4)
        destinations = [self.output / f"{stem}.svg", self.output / f"{stem}.png"]
        fig.savefig(destinations[0], facecolor="white")
        fig.savefig(destinations[1], dpi=160, facecolor="white")
        plt.close(fig)
        sources = []
        for key in csv_sources:
            path = self.summary_path if key == "summary" else self.convergence_path
            sources.append(dict(path=path.relative_to(ROOT).as_posix(), sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        self.charts.append(dict(chart=stem, files=[p.relative_to(ROOT).as_posix() for p in destinations],
            evidence_scope=scope, csv_sources=sources, filters=filters, fields=fields,
            run_ids=sorted({r["run_id"] for r in rows}), claims=claims, caption=short_caption,
            full_caption=caption,
            display_floor_for_relative_PD_gap=FLOOR, signed_objective_gap_values_modified=False))

    def convergence_outer(self):
        fig, axes = plt.subplots(1, 2, figsize=(12.8, 5.2))
        used = []
        for ax, experiment, dataset in zip(axes, ["E01", "E02"], ["Diabetes · n=353, d=10", "Synthetic · n=1000, d=200"]):
            for algorithm in ALGORITHMS:
                row, history = self.trace(algorithm, experiment); used.append(row)
                x = [int(r["iteration"]) for r in history]
                gap = display_gap(np.array([number(r, "relative_duality_gap") for r in history]))
                ax.plot(x, gap, color=COLORS[algorithm], linewidth=2.8, label=algorithm)
                ax.plot(x[-1], gap[-1], marker=MARKERS[algorithm], color=COLORS[algorithm], markersize=7)
            ax.axhline(TOLERANCE, color="#475569", linewidth=1.5, linestyle="--")
            ax.set_title(f"{experiment} · {'Diabetes' if experiment == 'E01' else 'S200'}", loc="left", pad=14)
            decorate(ax, "Native outer update", "Primal–dual gap / S", logy=True)
        shared_legend(fig, axes[0])
        self.save(fig, "fig01_convergence_outer", "evidence_scope: original. λ=0.1λmax. One trace per algorithm; dashed line is G/S=10⁻⁶. CD updates are complete coordinate sweeps. Native update costs differ; this figure does not rank mixed-host runtime.",
            scope="original", filters=dict(experiment_id=["E01", "E02"], mode="trace"), fields=["iteration", "relative_duality_gap"], rows=used,
            claims=["All displayed endpoints have recorded independently validated certificates.", "Native outer updates count different work across algorithms."])

    def objective_curves(self, signed_gap: bool):
        fig, axes = plt.subplots(1, 2, figsize=(12.8, 5.2)); used = []
        field = "relative_objective_gap" if signed_gap else "objective_value"
        for ax, experiment in zip(axes, ["E01", "E02"]):
            plotted = []
            for algorithm in ALGORITHMS:
                row, history = self.trace(algorithm, experiment); used.append(row)
                values = [number(r, field) for r in history]; plotted.append(values)
                ax.plot([int(r["iteration"]) for r in history], values, color=COLORS[algorithm], linewidth=2.6, label=algorithm)
            ax.set_title(f"{experiment} · {'Diabetes' if experiment == 'E01' else 'S200'}", loc="left", pad=14)
            if signed_gap:
                ax.axhline(0, color="#475569", linewidth=1.2)
                signed_scale(ax, plotted)
            else:
                ax.axhline(number(row, "reference_objective"), color="#475569", linestyle="--", linewidth=1.3)
            decorate(ax, "Native outer update", "Signed (P−Pref)/S" if signed_gap else "Original objective P(β)")
        shared_legend(fig, axes[0])
        stem = "fig02_signed_objective_gap" if signed_gap else "fig03_objective_values"
        caption = ("evidence_scope: original. Raw signed differences from a certified numerical reference; no absolute values or clipping. Symmetric log scale has a linear band at ±10⁻¹². Native update costs differ."
                   if signed_gap else "evidence_scope: original. The original normalized LASSO objective uses one coefficient vector β; ADMM is evaluated at β=z. Dashed lines show the certified numerical reference. Native update costs differ.")
        self.save(fig, stem, caption, scope="original", filters=dict(experiment_id=["E01", "E02"], mode="trace"), fields=["iteration", field, "reference_objective"], rows=used,
            claims=["Original objective and signed reference gap are reported separately from the primal–dual stopping certificate."])

    def fista_oscillation(self):
        candidates = []
        for experiment in ["E01", "E03"]:
            row, history = self.trace("FISTA", experiment)
            value = np.array([number(r, "objective_value") for r in history])
            increases = np.diff(value)
            threshold = 1e-12 * number(row, "objective_scale")
            rising = np.flatnonzero(increases > threshold)
            if len(rising):
                index = int(rising[np.argmax(increases[rising])])
                candidates.append((increases[index], index, row, history, len(rising)))
        if not candidates:
            raise ValueError("No verified FISTA objective increase in E01/E03; do not fabricate an oscillation example")
        increase, index, row, history, count = max(candidates, key=lambda v: v[0])
        x = np.array([int(r["iteration"]) for r in history]); y = np.array([number(r, "objective_value") for r in history])
        fig, axes = plt.subplots(1, 2, figsize=(12.8, 5.2))
        for ax in axes:
            ax.plot(x, y, color=COLORS["FISTA"], linewidth=2.7, label="FISTA")
            ax.axhline(number(row, "reference_objective"), color="#475569", linestyle="--", linewidth=1.3, label="Reference")
            decorate(ax, "FISTA update", "Original objective P(β)")
        axes[0].set_title(f"{row['experiment_id']} · full trace", loc="left", pad=14)
        start, end = max(0, index-6), min(len(x)-1, index+9)
        local = y[start:end+1]
        padding = max(float(np.ptp(local))*.18, increase*.5)
        axes[1].set(xlim=(x[start], x[end]), ylim=(float(local.min())-padding, float(local.max())+padding))
        axes[1].set_title("Measured increase · zoom", loc="left", pad=14)
        axes[1].plot(x[index:index+2], y[index:index+2], color="#a12338", marker="o", linewidth=3.8, markersize=8, label=f"ΔP = +{increase:.4g}")
        axes[1].ticklabel_format(axis="y", style="plain", useOffset=False)
        axes[0].legend(frameon=False); axes[1].legend(frameon=False, fontsize=21)
        caption = f"evidence_scope: original. FISTA {row['experiment_id']} has {count} recorded increases exceeding 10⁻¹²S. Highlight: update {x[index]}→{x[index+1]}, ΔP=+{increase:.6g}. This observed nonmonotonicity is consistent with the unrestarted FISTA implementation."
        self.save(fig, "fig04_fista_oscillation", caption, scope="original", filters=dict(algorithm="FISTA", experiment_id=row["experiment_id"], mode="trace"), fields=["iteration", "objective_value", "reference_objective", "objective_scale"], rows=[row],
            claims=[f"Actual objective rises by {increase:.17g} at update {x[index]} to {x[index+1]}.", f"{count} checkpoint increases exceed the protocol's floating point allowance."])

    def shared_trace_time(self, *, objective_gap=True):
        fig, ax = plt.subplots(figsize=(12.8, 5.2)); used = []
        plotted = []
        for algorithm in ALGORITHMS:
            row, history = self.trace(algorithm, "E02", "same_machine_supplement"); used.append(row)
            time = np.array([number(r, "elapsed_seconds") for r in history])
            gap = (np.array([number(r, "objective_gap") for r in history])/number(row, "objective_scale")
                   if objective_gap else display_gap(np.array([number(r, "relative_duality_gap") for r in history])))
            plotted.append(gap)
            ax.plot(time, gap, color=COLORS[algorithm], linewidth=3, label=algorithm)
            ax.plot(time[-1], gap[-1], color=COLORS[algorithm], marker=MARKERS[algorithm], markersize=8)
        ax.axhline(0 if objective_gap else TOLERANCE, color="#475569", linestyle="--", linewidth=1.4)
        decorate(ax, "Elapsed time (s)", "Objective gap / S" if objective_gap else "Primal–dual gap / S", logy=not objective_gap)
        if objective_gap:
            signed_scale(ax, plotted)
        ax.legend(frameon=False, loc="upper right", ncol=2)
        host = used[0]["host_label"]
        metric_caption = "Signed (P−Pref)/S, S=max(P0,10⁻¹²); symlog retains negative values and zero." if objective_gap else "Relative PD gap; dashed line is the common 10⁻⁶ stopping target."
        self.save(fig, "fig05_shared_trace_time_E02" if objective_gap else "fig05b_shared_PD_gap_time_E02", f"evidence_scope: same_machine_supplement. E02/S200, {host}; requested single-thread. {metric_caption} Trace time includes cold setup and a diagnostic after each update; ranking uses separate timing runs.",
            scope="same_machine_supplement", filters=dict(experiment_id="E02", mode="trace"), fields=["elapsed_seconds", "objective_gap" if objective_gap else "relative_duality_gap", "objective_scale", "host_label"], rows=used,
            claims=["All four displayed traces were rerun on the same recorded machine with one shared evaluator and timer.", "Trace time includes diagnostics at every update.", "Requested single-thread controls were recorded; Accelerate runtime thread count was not observed."])

    def shared_timing(self):
        fig, axes = plt.subplots(1, 2, figsize=(12.8, 5.2)); used = []; claims = []
        for ax, experiment in zip(axes, ["E01", "E02"]):
            for index, algorithm in enumerate(ALGORITHMS):
                rows = select(self.summary, evidence_scope="same_machine_supplement", experiment_id=experiment, algorithm=algorithm, mode="timing")
                if len(rows) != 3:
                    raise ValueError(f"Expected 3 timing repeats for {experiment}/{algorithm}")
                used.extend(rows)
                values = np.array([number(r, "runtime_seconds") for r in rows])*1000
                certified = all(r["convergence_status"] == "converged" and r["validation_status"] == "pass" for r in rows)
                median = float(np.median(values))
                ax.bar(index, median, color=COLORS[algorithm], width=.62, alpha=1 if certified else .25)
                ax.errorbar(index, median, yerr=[[median-values.min()], [values.max()-median]], color="#0f172a", capsize=6, linewidth=1.7, marker="none")
                ax.text(index, values.max()+max(float(values.max())*.05, .025), f"{median:.3g}", ha="center", va="bottom", fontsize=22)
                claims.append(f"{experiment}/{algorithm}: median={median:.9g} ms; min={values.min():.9g}, max={values.max():.9g}; certified={certified}.")
            ax.set_title(f"{experiment} · {'Diabetes' if experiment == 'E01' else 'S200'}", loc="left", pad=14)
            ax.set_xticks(range(4), ALGORITHMS)
            decorate(ax, "", "Total time (ms)")
            bottom, top = ax.get_ylim(); ax.set_ylim(0, top*1.18)
        self.save(fig, "fig06_shared_timing_E01_E02", "evidence_scope: same_machine_supplement. Requested single-thread; cold total time includes setup and common diagnostics every 5 native updates. Center: median of 3 runs. Whiskers: observed min–max, not confidence intervals. Shared-machine reruns cover only E01/E02.",
            scope="same_machine_supplement", filters=dict(experiment_id=["E01", "E02"], mode="timing"), fields=["runtime_seconds", "convergence_status", "validation_status"], rows=used, claims=claims, csv_sources=("summary",))

    def regularization(self, dataset: str):
        ids = ["E03", "E04", "E01", "E05", "E06"] if dataset == "DIA" else ["E07", "E08", "E02", "E09", "E10"]
        fig, axes = plt.subplots(1, 2, figsize=(12.8, 5.2)); used = []
        count_by_algorithm = {}; rmse_by_algorithm = {}
        for i, algorithm in enumerate(ALGORITHMS):
            rows = [self.trace(algorithm, e)[0] for e in ids]; used.extend(rows)
            x = [number(r, "lambda_ratio") for r in rows]
            count = [number(r, "nonzero_count") for r in rows]
            rmse = [number(r, "test_rmse") for r in rows]
            count_by_algorithm[algorithm] = count; rmse_by_algorithm[algorithm] = rmse
            for ax, values in zip(axes, [count, rmse]):
                ax.plot(x, values, color=COLORS[algorithm], linestyle=LINESTYLES[algorithm], linewidth=2.8-i*.28,
                        marker=MARKERS[algorithm], markersize=13-i*2.1, markerfacecolor="none", markeredgewidth=1.7, label=algorithm)
                ax.set_xscale("log"); ax.set_xticks([.01, .03, .1, .3, 1], [".01", ".03", ".10", ".30", "1.00"])
        decorate(axes[0], "λ / λmax", "Nonzeros")
        decorate(axes[1], "λ / λmax", "Test RMSE")
        axes[0].set_title(f"{dataset} · sparsity", loc="left", pad=14)
        axes[1].set_title(f"{dataset} · prediction", loc="left", pad=14)
        shared_legend(fig, axes[0])
        max_rmse_spread = max(max(rmse_by_algorithm[a][j] for a in ALGORITHMS)-min(rmse_by_algorithm[a][j] for a in ALGORITHMS) for j in range(5))
        counts_agree = all(count_by_algorithm[a] == count_by_algorithm[ALGORITHMS[0]] for a in ALGORITHMS)
        self.save(fig, f"fig0{'8' if dataset == 'DIA' else '7'}_regularization_{dataset}",
            f"evidence_scope: original. Certified trace finals; markers are nested because solutions nearly overlap. Nonzero counts agree across methods: {counts_agree}. Maximum cross-method RMSE spread: {max_rmse_spread:.3g}. The fixed grid does not select λ from test performance.",
            scope="original", filters=dict(dataset_id=dataset, experiment_id=ids, mode="trace"), fields=["lambda_ratio", "nonzero_count", "test_rmse"], rows=used,
            claims=[f"Identical nonzero counts across all algorithms: {counts_agree}.", f"Maximum cross-algorithm test RMSE spread is {max_rmse_spread:.17g}.", "The grid documents a sparsity–prediction tradeoff without a test-set tuning claim."], csv_sources=("summary",))

    def within_host_scaling(self):
        fig, axes = plt.subplots(1, 4, figsize=(12.8, 5.2)); used = []
        for ax, algorithm in zip(axes, ALGORITHMS):
            medians = []; lower = []; upper = []; host = None
            for experiment in ["E11", "E02", "E12"]:
                rows = select(self.summary, evidence_scope="original", experiment_id=experiment, algorithm=algorithm, mode="timing")
                if len(rows) != 3: raise ValueError(f"Expected three original timing repeats for {algorithm}/{experiment}")
                used.extend(rows); host = rows[0]["host_label"]
                values = np.array([number(r, "runtime_seconds") for r in rows])*1000
                med = float(np.median(values)); medians.append(med); lower.append(med-values.min()); upper.append(values.max()-med)
            ax.errorbar([100, 200, 400], medians, yerr=[lower, upper], color=COLORS[algorithm], marker=MARKERS[algorithm], linewidth=2.6, markersize=8, capsize=5)
            host_display = f"Xeon {host.split()[-1]}" if "XEON" in host.upper() else host
            ax.set_title(f"{algorithm}\n{host_display}", loc="left", pad=14, fontsize=22)
            ax.set_xscale("log", base=2)
            ax.set_xticks([100, 200, 400], ["100", "200", "400"])
            ax.set_xlim(83, 480)
            decorate(ax, "d (log₂)", "Time (ms)")
            ax.set_ylim(bottom=0)
        self.save(fig, "fig09_within_host_dimension_scaling", "evidence_scope: original. Each facet uses that algorithm's own local host/campaign and its own y-axis. Median with observed min–max (3 timing runs). One fixed absolute λ=0.1λmax(S200). This is within-host scaling evidence; cross-hardware rankings are not supported.",
            scope="original", filters=dict(experiment_id=["E11", "E02", "E12"], mode="timing"), fields=["n_features", "runtime_seconds", "host_label", "environment_id"], rows=used,
            claims=["Original timings are displayed as four separate within-host facets with independent y-axes.", "Dimension increases add features while preserving all signal features and the same response."], csv_sources=("summary",))

    def admm_diagnostics(self):
        row, history = self.trace("ADMM", "E02")
        x = np.array([int(r["iteration"]) for r in history]); gap = np.array([number(r, "relative_duality_gap") for r in history])
        first_pass = next((r for r in history if int(r["iteration"]) > 0 and r["admm_residuals_met"] == "true"), None)
        fig, axes = plt.subplots(1, 2, figsize=(12.8, 5.2))
        for key, eps, label, style in [("admm_r_norm", "admm_eps_primal", "Primal r / εprimal", "-"), ("admm_s_norm", "admm_eps_dual", "Dual s / εdual", "--")]:
            ratio = np.array([number(r, key)/number(r, eps) for r in history])
            axes[0].plot(x, np.maximum(ratio, FLOOR), color=COLORS["ADMM"], linestyle=style, linewidth=2.9, label=label)
        axes[0].axhline(1, color="#475569", linestyle=":", linewidth=1.5)
        axes[1].plot(x, display_gap(gap), color=COLORS["ADMM"], linewidth=2.9, label="Common gap G/S")
        axes[1].axhline(TOLERANCE, color="#475569", linestyle="--", linewidth=1.5)
        if first_pass:
            k = int(first_pass["iteration"])
            for ax in axes: ax.axvline(k, color="#64748b", linestyle=":", linewidth=1.5)
            axes[1].scatter([k], [number(first_pass, "relative_duality_gap")], color="#64748b", s=60, zorder=4)
            axes[1].annotate(f"Residuals: {k}", xy=(k, number(first_pass, "relative_duality_gap")), xytext=(.02, .35), textcoords="axes fraction", fontsize=22, arrowprops=dict(arrowstyle="->", color="#64748b"))
        axes[1].scatter([x[-1]], [max(gap[-1], FLOOR)], color=COLORS["ADMM"], s=65, zorder=4)
        axes[1].annotate(f"Gap pass: {x[-1]}", xy=(x[-1], max(gap[-1], FLOOR)), xytext=(.06, .16), textcoords="axes fraction", fontsize=22, arrowprops=dict(arrowstyle="->", color=COLORS["ADMM"]))
        axes[0].set_title("Splitting agreement", loc="left", pad=14); axes[1].set_title("Common certificate", loc="left", pad=14)
        decorate(axes[0], "ADMM update", "Residual / threshold", logy=True); decorate(axes[1], "ADMM update", "Primal–dual gap / S", logy=True)
        shared_legend(fig, axes[0], columns=2)
        residual_k = None if first_pass is None else int(first_pass["iteration"])
        residual_gap = math.nan if first_pass is None else number(first_pass, "relative_duality_gap")
        self.save(fig, "fig10_admm_residuals_and_gap", f"evidence_scope: original. E02 ADMM, ρ=1. Residual tests first pass after initialization at update {residual_k}, when G/S={residual_gap:.3g}; common gap reaches tolerance at update {x[-1]}. At initialization r=s=0 by construction. Zeros use a plot-only floor of 10⁻¹².",
            scope="original", filters=dict(experiment_id="E02", algorithm="ADMM", mode="trace"), fields=["iteration", "admm_r_norm", "admm_s_norm", "admm_eps_primal", "admm_eps_dual", "admm_residuals_met", "relative_duality_gap"], rows=[row],
            claims=[f"Residual criteria first pass at update {residual_k}; common gap at that point is {residual_gap:.17g}.", f"The common certificate terminates at update {x[-1]}.", "Residual tests and the primal–dual stopping certificate measure different properties."])

    def objective_table(self):
        fig, ax = plt.subplots(figsize=(12.8, 3.6)); ax.axis("off")
        used = []; values = []
        for algorithm in ALGORITHMS:
            e01 = self.trace(algorithm, "E01")[0]; e02 = self.trace(algorithm, "E02")[0]
            used.extend([e01, e02])
            values.append([algorithm, f"{number(e01, 'final_objective'):.6g}", f"{number(e01, 'relative_duality_gap'):.2e}", f"{number(e02, 'final_objective'):.6g}", f"{number(e02, 'relative_duality_gap'):.2e}"])
        table = ax.table(cellText=values, colLabels=["Algorithm", "E01: P", "E01: G/S", "E02: P", "E02: G/S"], bbox=[.005, .08, .99, .86], cellLoc="center", colWidths=[.16, .21, .21, .21, .21])
        table.auto_set_font_size(False); table.set_fontsize(24)
        for (r, c), cell in table.get_celld().items():
            cell.set_edgecolor("#e2e8f0"); cell.set_linewidth(.8)
            if r == 0:
                cell.set_facecolor("#f1f5f9"); cell.set_text_props(weight="bold", color="#0f172a")
            elif c == 0: cell.set_text_props(color=COLORS[ALGORITHMS[r-1]], weight="bold")
            else: cell.set_text_props(color="#0f172a")
        self.save(fig, "fig11_objective_certificate_table", "evidence_scope: original. Certified trace finals; objectives shown to 6 significant digits. Similar objectives are reported numerically without a truncated bar axis. The relative primal–dual gap is the independent stopping certificate (target 10⁻⁶), not an exact known objective error.",
            scope="original", filters=dict(experiment_id=["E01", "E02"], mode="trace"), fields=["final_objective", "relative_duality_gap", "validation_status"], rows=used,
            claims=["The original objective values agree to the displayed precision.", "All displayed relative primal–dual gaps satisfy the common target."], csv_sources=("summary",))

    def write_manifest(self):
        target = self.output / "plot_sources.json"
        target.write_text(json.dumps(dict(schema_version="1.0", generator="reproduce/make_experiment_figures.py",
            generator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            color_map=COLORS, figures=self.charts), ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary", default="analysis/Merged_Results.csv")
    parser.add_argument("--convergence", default="analysis/Convergence_Results.csv")
    parser.add_argument("--output", default="slides/figures/experiment_figures")
    args = parser.parse_args()
    paths = [(ROOT / p).resolve() for p in [args.summary, args.convergence, args.output]]
    if any(not p.is_relative_to(ROOT) for p in paths):
        parser.error("Sources and output must remain inside the final presentation package")
    charts = Charts(*paths)
    with plt.rc_context(STYLE):
        charts.convergence_outer()
        charts.objective_curves(True)
        charts.objective_curves(False)
        charts.fista_oscillation()
        charts.shared_trace_time()
        charts.shared_trace_time(objective_gap=False)
        charts.shared_timing()
        charts.regularization("S200")
        charts.regularization("DIA")
        charts.within_host_scaling()
        charts.admm_diagnostics()
        charts.objective_table()
    charts.write_manifest()
    print(f"Created {len(charts.charts)} SVG/PNG figure pairs and plot_sources.json in {charts.output.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
