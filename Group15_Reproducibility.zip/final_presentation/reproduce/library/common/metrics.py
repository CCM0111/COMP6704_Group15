"""Independent LASSO certificates and original-response-unit metrics.

These functions recompute residuals from X, y, and beta; solver caches are
intentionally not accepted. Formulas follow protocol 1.0.0, Appendix B.
"""
from __future__ import annotations

import numpy as np


def certify(X, y, beta, lambda_value, tolerance=1e-6):
    """Return the signed primal-dual gap, KKT diagnostic and common stop test."""
    X, y, beta = np.asarray(X), np.asarray(y), np.asarray(beta)
    if X.ndim != 2 or y.shape != (X.shape[0],) or beta.shape != (X.shape[1],):
        raise ValueError("Certificate input shapes do not agree")
    if min(X.shape) < 1 or not np.isfinite(lambda_value) or lambda_value <= 0:
        raise ValueError("A nonempty problem and finite positive lambda are required")
    if not np.isfinite(tolerance) or tolerance <= 0:
        raise ValueError("Certificate tolerance must be finite and positive")
    if not all(np.isfinite(a).all() for a in (X, y, beta)):
        raise ValueError("Certificate inputs must be finite")
    n = X.shape[0]
    r = y - X @ beta
    corr = X.T @ r / n
    p = float(r @ r / (2*n) + lambda_value * np.abs(beta).sum())
    scale = max(float(y @ y / (2*n)), 1e-12)
    factor = max(1.0, float(np.max(np.abs(corr))) / lambda_value)
    theta = (r / n) / (factor * (1.0 + 1e-14))
    dual = float(y @ theta - 0.5*n*(theta @ theta))
    raw_gap = p - dual
    feas = max(0.0, float(np.max(np.abs(X.T @ theta))) - lambda_value)
    feas /= max(lambda_value, 1e-12)
    grad = -corr
    active = beta != 0.0
    violation = np.maximum(np.abs(grad) - lambda_value, 0.0)
    violation[active] = np.abs(grad[active] + lambda_value*np.sign(beta[active]))
    kkt = float(np.max(violation)) / max(lambda_value, 1e-12)
    valid = bool(np.isfinite([p, dual, raw_gap, feas, kkt]).all()
                 and raw_gap >= -1e-12*scale and feas <= 1e-12)
    return dict(objective_value=p, dual_objective=dual,
                duality_gap=raw_gap, relative_duality_gap=raw_gap/scale,
                objective_scale=scale, dual_feasibility_violation=feas,
                kkt_violation=kkt, valid=valid,
                converged=bool(valid and max(raw_gap, 0.0)/scale <= tolerance))


def original_unit_metrics(Xtr, Xte, ytr_raw, yte_raw, y_mean, beta,
                          nz_threshold, truth_std=None):
    """Compute predictions in original y units without editing coefficients."""
    train_rmse = float(np.sqrt(np.mean((y_mean + Xtr@beta-ytr_raw)**2)))
    test_rmse = float(np.sqrt(np.mean((y_mean + Xte@beta-yte_raw)**2)))
    pred_support = np.abs(beta) > nz_threshold
    ans = dict(train_rmse=train_rmse, test_rmse=test_rmse,
               nonzero_count=int(pred_support.sum()),
               sparsity_ratio=1.0-float(pred_support.mean()),
               support_precision=None, support_recall=None,
               support_f1=None, coef_relative_error=None)
    if truth_std is not None:
        true_support = truth_std != 0.0
        if not true_support.any():
            raise ValueError("Synthetic truth must contain a nonzero coefficient")
        tp = int(np.count_nonzero(pred_support & true_support))
        precision = tp / int(pred_support.sum()) if pred_support.any() else 0.0
        recall = tp / int(true_support.sum())
        f1 = 2*precision*recall/(precision+recall) if precision+recall else 0.0
        ans.update(support_precision=precision, support_recall=recall,
                   support_f1=f1, coef_relative_error=float(
                       np.linalg.norm(beta-truth_std)/np.linalg.norm(truth_std)))
    return ans
