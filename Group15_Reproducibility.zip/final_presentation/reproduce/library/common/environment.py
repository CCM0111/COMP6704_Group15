"""Collect actual CPU-only runtime information; enforce the formal lock."""
from __future__ import annotations

import contextlib
from datetime import datetime, timezone
import importlib.metadata
import io
import json
import os
from pathlib import Path
import platform
import re
import socket
import subprocess
import sys
import time

from .data import canonical_hash

LOCKED_PACKAGES = {
    "numpy": "2.3.5", "scipy": "1.17.0", "scikit-learn": "1.8.0",
    "pandas": "2.2.3", "matplotlib": "3.10.8", "threadpoolctl": "3.6.0",
}
THREAD_VARIABLES = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                    "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")


def _command(args):
    result = subprocess.run(args, capture_output=True, text=True, timeout=15, check=True)
    return result.stdout.strip()


def _hardware():
    logical = os.cpu_count()
    cpu = platform.processor()
    physical = ram = None
    if sys.platform == "darwin":
        try:
            cpu = _command(["/usr/sbin/sysctl", "-n", "machdep.cpu.brand_string"])
            physical = int(_command(["/usr/sbin/sysctl", "-n", "hw.physicalcpu"]))
            logical = int(_command(["/usr/sbin/sysctl", "-n", "hw.logicalcpu"]))
            ram = int(_command(["/usr/sbin/sysctl", "-n", "hw.memsize"]))
        except (subprocess.SubprocessError, OSError, ValueError):
            # macOS sandbox profiles may deny sysctl while System Information
            # remains available. Keep only hardware fields, never serial/UUID.
            hardware = json.loads(_command([
                "/usr/sbin/system_profiler", "SPHardwareDataType", "-json"]))["SPHardwareDataType"][0]
            cpu = hardware.get("chip_type") or hardware.get("cpu_type")
            cores = re.search(r"^proc\s+(\d+):", hardware.get("number_processors", ""))
            if cores:
                physical = int(cores.group(1))
            else:
                physical = int(hardware["total_number_cores"])
            memory = re.fullmatch(r"([\d.]+)\s*(GB|MB|TB)", hardware["physical_memory"])
            if memory:
                ram = int(float(memory.group(1)) * 1024**{"MB": 2, "GB": 3, "TB": 4}[memory.group(2)])
    else:
        try:
            import psutil
            physical = psutil.cpu_count(logical=False)
            ram = int(psutil.virtual_memory().total)
        except ImportError:
            if hasattr(os, "sysconf"):
                ram = int(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES"))
            info = Path("/proc/cpuinfo")
            if info.exists():
                records = info.read_text().split("\n\n")
                core_ids = set()
                for record in records:
                    fields = dict(line.split(":", 1) for line in record.splitlines() if ":" in line)
                    fields = {k.strip(): v.strip() for k, v in fields.items()}
                    cpu = fields.get("model name", cpu)
                    if "core id" in fields:
                        core_ids.add((fields.get("physical id", "0"), fields["core id"]))
                if core_ids:
                    physical = len(core_ids)
    if not cpu or not all(isinstance(v, int) and v > 0 for v in (physical, logical, ram)):
        raise RuntimeError("Could not collect actual CPU/core/RAM information")
    return cpu, physical, logical, ram


def capture_environment(project_root, git_commit="unversioned"):
    """Capture while the runner's threadpool_limits(limits=1) context is active."""
    import numpy as np
    from threadpoolctl import threadpool_info

    cpu, physical, logical, ram = _hardware()
    observed = threadpool_info()
    package_versions = {}
    for name in LOCKED_PACKAGES:
        try:
            package_versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            package_versions[name] = "not-installed"
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        np.show_config()
    try:
        freeze = _command([sys.executable, "-m", "pip", "freeze"]).splitlines()
        freeze_source = "python -m pip freeze"
    except (subprocess.SubprocessError, OSError):
        freeze = sorted(f"{d.metadata['Name']}=={d.version}"
                        for d in importlib.metadata.distributions() if d.metadata.get("Name"))
        freeze_source = "importlib.metadata (pip unavailable)"
    backend = "; ".join(sorted(set(
        f"{p.get('internal_api', p.get('user_api', 'unknown'))}:"
        f"{p.get('prefix', '')}:{p.get('version', '')}"
        for p in observed))) or "No loaded BLAS threadpool reported by threadpoolctl"
    env = dict(
        schema_version="1.0.0", host_id=socket.gethostname(), cpu_model=cpu,
        physical_cores=physical, logical_cores=logical, ram_bytes=ram,
        os=platform.platform(), architecture=platform.machine(),
        python_version=platform.python_version(), python_executable=sys.executable,
        packages=package_versions, blas_backend=backend,
        threads={"configured_limit": 1,
                 "environment": {k: os.environ.get(k) for k in (*THREAD_VARIABLES, "PYTHONHASHSEED")},
                 "observed": observed},
        timer_resolution_seconds=float(time.get_clock_info("perf_counter").resolution),
        git_commit=git_commit, pip_freeze=freeze, pip_freeze_source=freeze_source,
        numpy_config=out.getvalue(),
        captured_at_utc=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"))
    # Library paths are installations, not the identity of the CPU/BLAS runtime.
    stable = {k: env[k] for k in ("schema_version", "host_id", "cpu_model",
        "physical_cores", "logical_cores", "ram_bytes", "os", "architecture",
        "python_version", "packages", "blas_backend", "timer_resolution_seconds")}
    stable["threads"] = {
        "configured_limit": env["threads"]["configured_limit"],
        "environment": env["threads"]["environment"],
        "observed": [{k: v for k, v in p.items() if k != "filepath"} for p in observed]}
    env["environment_id"] = canonical_hash(stable)
    return env


def enforce_formal_environment(env):
    """Raise for any departure from the protocol's frozen formal environment."""
    errors = []
    if env["python_version"].split(".")[:2] != ["3", "12"]:
        errors.append("formal runs require Python 3.12.x")
    for name, version in LOCKED_PACKAGES.items():
        actual = env["packages"].get(name)
        if actual != version:
            errors.append(f"{name} must be {version}; found {actual}")
    thread_env = env["threads"].get("environment", {})
    for name in THREAD_VARIABLES:
        if thread_env.get(name) != "1":
            errors.append(f"{name} must be set to 1 before importing NumPy/SciPy")
    if thread_env.get("PYTHONHASHSEED") != "0":
        errors.append("PYTHONHASHSEED must be set to 0 at process start")
    for pool in env["threads"].get("observed", []):
        if pool.get("num_threads") != 1:
            errors.append(f"observed {pool.get('internal_api')} uses {pool.get('num_threads')} threads")
    if errors:
        raise RuntimeError("Formal environment preflight failed: " + "; ".join(errors))
