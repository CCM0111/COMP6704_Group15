"""Protocol 1.0.0 CSV column order and strict serialization."""
import csv
import math
from pathlib import Path

SUMMARY_COLUMNS = "schema_version,protocol_version,is_example,campaign_id,experiment_id,dataset_id,algorithm,run_id,mode,repeat_index,seed,problem_id,config_id,implementation_id,environment_id,dataset_sha256,n_samples,n_test_samples,n_features,lambda,lambda_max,lambda_ratio,objective_scale,max_iterations,max_runtime_seconds,stopping_tolerance,check_every,iterations,runtime_seconds,setup_seconds,solve_seconds,time_to_tolerance_seconds,final_objective,reference_objective,objective_gap,relative_objective_gap,duality_gap,relative_duality_gap,dual_feasibility_violation,kkt_violation,train_rmse,test_rmse,nonzero_threshold,nonzero_count,sparsity_ratio,support_precision,support_recall,support_f1,coef_relative_error,convergence_status,stop_reason,validation_status,config_file,solution_file,error_file".split(",")
CONVERGENCE_COLUMNS = "schema_version,is_example,campaign_id,experiment_id,dataset_id,algorithm,run_id,mode,config_id,iteration,elapsed_seconds,objective_value,objective_gap,relative_objective_gap,duality_gap,relative_duality_gap,dual_feasibility_violation,kkt_violation,nonzero_count,gradient_evaluations,coordinate_updates,linear_system_solves,diagnostic_evaluations,admm_r_norm,admm_s_norm,admm_eps_primal,admm_eps_dual,admm_residuals_met,is_final".split(",")

def cell(value):
    if value is None:
        return ""
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite CSV value")
        return format(value, ".17g")
    return str(value)

def append_csv(path, columns, rows):
    path = Path(path)
    exists = path.exists()
    if exists:
        with path.open(newline="", encoding="utf-8") as f:
            if next(csv.reader(f)) != columns:
                raise ValueError(f"Unexpected CSV header: {path}")
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, columns, lineterminator="\n")
        if not exists:
            writer.writeheader()
        for row in rows:
            writer.writerow({key: cell(row.get(key)) for key in columns})
