"""Load only hash-verified, frozen inputs; development assets need an opt-in."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np

from .metrics import certify

DATASET_SHAPES = {"DIA": (442, 353, 89, 10), "S100": (1250, 1000, 250, 100),
                  "S200": (1250, 1000, 250, 200), "S400": (1250, 1000, 250, 400)}
EXPERIMENT_SPECS = [
    ("E01", "DIA", .10, 10, ["EXP01", "EXP02", "EXP03"]),
    ("E02", "S200", .10, 30, ["EXP01", "EXP02", "EXP03", "EXP04"]),
    ("E03", "DIA", .01, 10, ["EXP02", "EXP03"]),
    ("E04", "DIA", .03, 10, ["EXP02", "EXP03"]),
    ("E05", "DIA", .30, 10, ["EXP02", "EXP03"]),
    ("E06", "DIA", 1.0, 10, ["EXP02", "EXP03"]),
    ("E07", "S200", .01, 30, ["EXP02", "EXP03"]),
    ("E08", "S200", .03, 30, ["EXP02", "EXP03"]),
    ("E09", "S200", .30, 30, ["EXP02", "EXP03"]),
    ("E10", "S200", 1.0, 30, ["EXP02", "EXP03"]),
    ("E11", "S100", None, 20, ["EXP02", "EXP04"]),
    ("E12", "S400", None, 45, ["EXP02", "EXP04"]),
]


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def canonical_hash(value):
    """Protocol canonical JSON hash, converting every float to float.hex()."""
    def convert(item):
        if isinstance(item, (float, np.floating)):
            if not math.isfinite(float(item)):
                raise ValueError("Identity hashes cannot contain nonfinite floats")
            return float(item).hex()
        if isinstance(item, np.integer):
            return int(item)
        if isinstance(item, np.bool_):
            return bool(item)
        if isinstance(item, dict):
            return {key: convert(val) for key, val in item.items()}
        if isinstance(item, (list, tuple)):
            return [convert(val) for val in item]
        return item
    payload = json.dumps(convert(value), sort_keys=True, separators=(",", ":"),
                         ensure_ascii=False, allow_nan=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _read_json(path):
    with Path(path).open(encoding="utf-8") as stream:
        obj = json.load(stream, parse_constant=lambda s: (_ for _ in ()).throw(
            ValueError(f"Nonfinite JSON value: {s}")))
    if not isinstance(obj, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return obj


def _within(root, relative):
    root = Path(root).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError(f"Manifest path escapes its root: {relative}")
    return path


def _check_hash(path, expected, description):
    actual = sha256_file(path)
    if not isinstance(expected, str) or len(expected) != 64 or actual != expected:
        raise ValueError(f"SHA-256 mismatch for {description}: {path}")
    return actual


def _close(actual, expected, label, rtol=2e-12, atol=1e-12):
    if not np.isfinite(actual) or not np.isclose(actual, expected, rtol=rtol, atol=atol):
        raise ValueError(f"Invalid {label}: manifest={actual}, computed={expected}")


def _development_flag(obj, development, label):
    flag = obj.get("development_only", False)
    if development and flag is not True:
        raise ValueError(f"Development assets must explicitly mark development_only=true: {label}")
    if not development and flag is not False:
        raise ValueError(f"Development assets cannot be used as formal inputs: {label}")


def _dataset_catalog(base, development):
    datasets_dir = base / "datasets"
    top_file = datasets_dir / "manifest.json"
    top = _read_json(top_file)
    _development_flag(top, development, top_file)
    if top.get("dataset_version") != "datasets-v1":
        raise ValueError("Unsupported dataset version")
    entries = top.get("datasets", [])
    if len(entries) != 4 or {e.get("dataset_id") for e in entries} != set(DATASET_SHAPES):
        raise ValueError("Dataset manifest must bind exactly DIA/S100/S200/S400")
    catalog = {}
    for entry in entries:
        dataset_id = entry["dataset_id"]
        path = _within(datasets_dir, entry["manifest_file"])
        _check_hash(path, entry["manifest_sha256"], "per-dataset manifest")
        manifest = _read_json(path)
        _development_flag(manifest, development, path)
        if manifest.get("dataset_id") != dataset_id:
            raise ValueError("Dataset manifest ID mismatch")
        data_path = path.parent / "data.npz"
        checksum = _check_hash(data_path, entry["npz_sha256"], "dataset NPZ")
        if manifest.get("npz_sha256") != checksum:
            raise ValueError("Top and per-dataset NPZ hashes disagree")
        catalog[dataset_id] = (manifest, data_path)
    return catalog, sha256_file(top_file)


def _read_dataset(dataset_id, manifest, path):
    total, n, nt, d = DATASET_SHAPES[dataset_id]
    for key, value in [("n_total", total), ("n_train", n), ("n_test", nt), ("n_features", d),
                       ("split_seed", 20261021), ("dataset_version", "datasets-v1"),
                       ("preprocessing_version", "train-zscore-ycenter-v1")]:
        if manifest.get(key) != value:
            raise ValueError(f"Dataset {dataset_id}: invalid manifest {key}")
    floats = {"X_train": (n, d), "X_test": (nt, d), "y_train": (n,),
              "y_test_centered": (nt,), "y_train_raw": (n,), "y_test_raw": (nt,),
              "x_mean": (d,), "x_scale": (d,), "y_mean": ()}
    if dataset_id != "DIA":
        floats.update(beta_true_raw=(d,), beta_true_std=(d,))
    integers = {"train_indices": (n,), "test_indices": (nt,)}
    with np.load(path, allow_pickle=False) as archive:
        if set(archive.files) != set(floats) | set(integers):
            raise ValueError(f"Dataset {dataset_id}: unexpected or missing NPZ keys")
        arrays = {k: archive[k] for k in archive.files}
    for key, shape in {**floats, **integers}.items():
        a = arrays[key]
        dtype = np.dtype("int64") if key in integers else np.dtype("float64")
        if a.shape != shape or a.dtype != dtype or not np.isfinite(a).all():
            raise ValueError(f"Dataset {dataset_id}: invalid dtype, shape or finite values: {key}")
    for key in ("X_train", "X_test"):
        arrays[key] = np.asfortranarray(arrays[key], dtype=np.float64)
    for key in ("y_train", "y_train_raw", "y_test_raw", "y_test_centered"):
        arrays[key] = np.ascontiguousarray(arrays[key], dtype=np.float64)
    permutation = np.random.Generator(np.random.PCG64(20261021)).permutation(total)
    for key, expected in (("train_indices", permutation[:n]), ("test_indices", permutation[n:])):
        indices = arrays[key]
        if not np.array_equal(indices, expected):
            raise ValueError(f"Dataset {dataset_id}: frozen split/order differs: {key}")
        checksum = hashlib.sha256(np.asarray(indices, dtype="<i8").tobytes(order="C")).hexdigest()
        if checksum != manifest.get(f"{key}_sha256"):
            raise ValueError(f"Dataset {dataset_id}: index hash mismatch: {key}")
    constants = manifest.get("constant_columns")
    if not isinstance(constants, list) or any(type(j) is not int or not 0 <= j < d for j in constants):
        raise ValueError("Invalid constant-column list")
    if len(set(constants)) != len(constants) or (arrays["x_scale"] <= 0).any():
        raise ValueError("Invalid feature scales or duplicate constant columns")
    X, y = arrays["X_train"], arrays["y_train"]
    nonconstant = np.ones(d, dtype=bool)
    nonconstant[constants] = False
    if np.max(np.abs(X.mean(axis=0))) > 1e-10 or abs(float(y.mean())) > 1e-10:
        raise ValueError(f"Dataset {dataset_id}: training data are not centered")
    if nonconstant.any() and np.max(np.abs(X.var(axis=0, ddof=0)[nonconstant]-1)) > 1e-10:
        raise ValueError(f"Dataset {dataset_id}: training columns lack unit population variance")
    if constants and (np.max(np.abs(X[:, constants])) > 1e-10
                      or not np.array_equal(arrays["x_scale"][constants], np.ones(len(constants)))):
        raise ValueError("Constant columns must be zero in training with scale=1")
    y_mean = float(arrays["y_mean"])
    if not np.allclose(y, arrays["y_train_raw"]-y_mean, rtol=0, atol=1e-12):
        raise ValueError("Centered and raw training responses disagree")
    if not np.allclose(arrays["y_test_centered"], arrays["y_test_raw"]-y_mean, rtol=0, atol=1e-12):
        raise ValueError("Centered and raw test responses disagree")
    _close(y_mean, float(arrays["y_train_raw"].mean()), "training y mean")
    _close(manifest["lambda_max"], float(np.max(np.abs(X.T @ y))/n), "lambda_max")
    p0 = float(y@y/(2*n))
    _close(manifest["P0"], p0, "P0")
    _close(manifest["objective_scale"], max(p0, 1e-12), "objective scale")
    _close(manifest["nz_threshold"], 1e-6*max(1, float(np.sqrt(np.mean(y*y)))), "nz threshold")
    if dataset_id != "DIA":
        truth = arrays["beta_true_raw"]
        if (np.count_nonzero(truth) != 10 or np.any(truth[100:] != 0)
                or not np.all(np.abs(truth[truth != 0]) == 2)):
            raise ValueError("Synthetic truth does not match the frozen 10-feature signal")
        if not np.allclose(arrays["beta_true_std"], truth*arrays["x_scale"], rtol=0, atol=1e-14):
            raise ValueError("Synthetic truth is not in standardized coordinates")
    return arrays


def _experiments(base, catalog, manifest_hash, development):
    path = base / "configs" / "experiments.json"
    config = _read_json(path)
    _development_flag(config, development, path)
    if config.get("protocol_version") != "1.0.0":
        raise ValueError("Unsupported experiment protocol version")
    if config.get("dataset_manifest_sha256") != manifest_hash:
        raise ValueError("experiments.json is not bound to this dataset manifest")
    experiments = config.get("experiments", [])
    if len(experiments) != 12:
        raise ValueError("The mandatory grid must have exactly 12 experiment configs")
    anchor = .1*catalog["S200"][0]["lambda_max"]
    for e, (eid, did, ratio, seconds, groups) in zip(experiments, EXPERIMENT_SPECS):
        lm = catalog[did][0]["lambda_max"]
        expected_lambda = ratio*lm if ratio is not None else anchor
        expected = {"experiment_id": eid, "dataset_id": did,
                    "lambda_policy": "own_ratio" if ratio is not None else "anchor_S200",
                    "anchor_dataset_id": None if ratio is not None else "S200",
                    "max_iterations": 10000, "max_runtime_seconds": seconds,
                    "stopping_tolerance": 1e-6, "analysis_groups": groups}
        for key, val in expected.items():
            if e.get(key) != val:
                raise ValueError(f"Frozen experiment {eid}: invalid {key}")
        _close(e.get("lambda_value"), expected_lambda, f"{eid} lambda", atol=1e-15)
        _close(e.get("lambda_ratio"), expected_lambda/lm, f"{eid} ratio", atol=1e-15)
        if e.get("modes") != [
            {"mode": "trace", "repeat_indices": [0], "check_every": 1},
            {"mode": "timing", "repeat_indices": [1, 2, 3], "check_every": 5}]:
            raise ValueError(f"Frozen experiment {eid}: modes/check cadence differ")
    return {e["experiment_id"]: e for e in experiments}


def _reference(base, experiment, arrays, dataset_hash, development):
    refs_dir = base / "references"
    manifest_path = refs_dir / "manifest.json"
    manifest = _read_json(manifest_path)
    _development_flag(manifest, development, manifest_path)
    entries = manifest.get("references", [])
    ids = [e.get("experiment_id") for e in entries]
    if len(entries) != 12 or set(ids) != {s[0] for s in EXPERIMENT_SPECS}:
        raise ValueError("Reference manifest must contain E01–E12 exactly once")
    eid = experiment["experiment_id"]
    entry = entries[ids.index(eid)]
    path = _within(refs_dir, entry["reference_file"])
    checksum = _check_hash(path, entry["sha256"], "reference NPZ")
    lam = experiment["lambda_value"]
    if entry.get("dataset_sha256") != dataset_hash:
        raise ValueError("Reference manifest dataset binding differs")
    if entry.get("lambda_value") != lam:
        raise ValueError("Reference manifest lambda binding differs")
    with np.load(path, allow_pickle=False) as archive:
        ref = {k: archive[k] for k in archive.files}
    required = ("beta_ref", "P_ref", "D_ref", "reference_duality_gap", "lambda_value",
                "dataset_sha256", "experiment_id", "runtime_seconds", "environment_json")
    if any(key not in ref for key in required):
        raise ValueError("Missing reference metadata/certificate")
    for key in required[1:]:
        if ref[key].shape != ():
            raise ValueError(f"Reference metadata must be scalar: {key}")
    if ref["beta_ref"].dtype != np.float64 or ref["beta_ref"].shape != (arrays["X_train"].shape[1],):
        raise ValueError("Reference beta has invalid dtype or shape")
    for key in ("P_ref", "D_ref", "reference_duality_gap", "lambda_value", "runtime_seconds"):
        if ref[key].dtype != np.float64 or not np.isfinite(ref[key]):
            raise ValueError(f"Reference metadata must be finite float64: {key}")
    ref = {k: (v.item() if v.shape == () else v) for k, v in ref.items()}
    if ref["dataset_sha256"] != dataset_hash or ref["experiment_id"] != eid or ref["lambda_value"] != lam:
        raise ValueError("Reference NPZ data/experiment/lambda binding differs")
    _development_flag(ref, development, path)
    if not 0 <= ref["runtime_seconds"] <= 90:
        raise ValueError("Reference generation exceeded its independent 90-second budget")
    reference_env = json.loads(ref["environment_json"])
    if not isinstance(reference_env, dict) or "python_version" not in reference_env:
        raise ValueError("Reference environment is missing")
    cert = certify(arrays["X_train"], arrays["y_train"], ref["beta_ref"], lam, tolerance=1e-10)
    if not cert["converged"]:
        raise ValueError("Reference failed the independently recomputed <=1e-10 certificate")
    for key, computed_key in (("P_ref", "objective_value"), ("D_ref", "dual_objective"),
                              ("reference_duality_gap", "duality_gap")):
        _close(ref[key], cert[computed_key], f"reference {key}", atol=2e-12*cert["objective_scale"])
    ref["certificate"] = cert
    return ref, checksum, path


def load_problem(project_root, experiment_id, development=False):
    """Load and authenticate protocol inputs, never regenerating missing data.

    Formal inputs live in datasets/, references/, configs/. Development inputs
    live solely below dev_assets/ and require development=True explicitly.
    """
    root = Path(project_root).resolve()
    base = root / "dev_assets" if development else root
    catalog, manifest_hash = _dataset_catalog(base, development)
    experiments = _experiments(base, catalog, manifest_hash, development)
    if experiment_id not in experiments:
        raise ValueError(f"Unknown mandatory experiment: {experiment_id}")
    experiment = experiments[experiment_id]
    # Verify the shared master relationship as well as each file's own hash.
    loaded = {did: _read_dataset(did, *entry) for did, entry in catalog.items()}
    anchor = loaded["S400"]
    for did in ("S100", "S200"):
        a = loaded[did]
        for key in ("y_train", "y_test_centered", "y_train_raw", "y_test_raw", "y_mean",
                    "train_indices", "test_indices"):
            if not np.array_equal(a[key], anchor[key]):
                raise ValueError(f"Synthetic master views differ in {key}")
        d = a["X_train"].shape[1]
        for key in ("X_train", "X_test"):
            if not np.array_equal(a[key], anchor[key][:, :d]):
                raise ValueError(f"Synthetic master shared columns differ in {key}")
        for key in ("x_mean", "x_scale", "beta_true_raw", "beta_true_std"):
            if not np.array_equal(a[key], anchor[key][:d]):
                raise ValueError(f"Synthetic master shared statistics differ in {key}")
    did = experiment["dataset_id"]
    manifest, data_file = catalog[did]
    a = loaded[did]
    reference, ref_hash, ref_file = _reference(base, experiment, a, manifest["npz_sha256"], development)
    return dict(X=a["X_train"], y=a["y_train"], X_test=a["X_test"],
                y_train_raw=a["y_train_raw"], y_test_raw=a["y_test_raw"],
                y_mean=float(a["y_mean"]), x_mean=a["x_mean"], x_scale=a["x_scale"],
                beta_true_std=a.get("beta_true_std"), manifest=manifest,
                experiment=experiment, reference=reference,
                dataset_sha256=manifest["npz_sha256"], reference_sha256=ref_hash,
                dataset_file=data_file.relative_to(root).as_posix(),
                reference_file=ref_file.relative_to(root).as_posix())
