"""Shared cold-start timing and certificate-based stopping for stateful solvers."""
from dataclasses import dataclass
from time import perf_counter_ns
from collections.abc import Mapping
from numbers import Integral, Real
import copy
import math
import traceback
import numpy as np
from .metrics import certify

@dataclass
class SolveResult:
    beta: np.ndarray | None
    state: object
    history: list
    metrics: dict | None
    iterations: int
    runtime_seconds: float
    setup_seconds: float
    solve_seconds: float
    convergence_status: str
    stop_reason: str
    error: dict | None

def _snapshot(state):
    """Copy changing vector state; keep immutable matrices/factors shared."""
    if state is None:
        return None
    ans = copy.copy(state)
    for key, value in vars(state).items():
        if isinstance(value, np.ndarray) and value.ndim <= 1:
            setattr(ans, key, value.copy())
    return ans

def _integer_setting(config, key, default, minimum):
    value = config.get(key, default)
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Integral):
        raise ValueError(f"{key} must be an integer >= {minimum}")
    if value < minimum:
        raise ValueError(f"{key} must be an integer >= {minimum}")
    return int(value)

def _real_setting(config, key, default, *, allow_zero=False):
    value = config.get(key, default)
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Real):
        raise ValueError(f"{key} must be a finite real number")
    value = float(value)
    if not math.isfinite(value) or (value < 0 if allow_zero else value <= 0):
        raise ValueError(f"{key} has an invalid value")
    return value

def run_one(solver, X, y, lambda_value, config):
    """No I/O, plots, reference solving, data conversion, or prediction in timer.

    config: max_iterations, max_runtime_seconds, stopping_tolerance,
    check_every, nonzero_threshold, algorithm_config (optional).
    """
    if not isinstance(config, Mapping):
        raise TypeError("config must be a mapping")
    max_iter = _integer_setting(config, "max_iterations", 10000, 0)
    budget = _real_setting(config, "max_runtime_seconds", 30.0)
    tol = _real_setting(config, "stopping_tolerance", 1e-6)
    every = _integer_setting(config, "check_every", 1, 1)
    threshold = _real_setting(config, "nonzero_threshold", 1e-6, allow_zero=True)
    algorithm = config.get("algorithm", getattr(solver, "ALGORITHM", "ADMM"))
    state = None
    history = []
    metrics = None
    error = None
    iteration = 0
    evaluations = 0
    setup = None
    stage = "initial_check"
    attempted = 0
    last_valid_time = None
    beta = None
    status, reason = "exception", "exception"
    checkpoint = None
    start = perf_counter_ns()

    def elapsed():
        return (perf_counter_ns() - start) * 1e-9

    def evaluate():
        nonlocal metrics, evaluations, last_valid_time, checkpoint
        evaluations += 1
        candidate_metrics = certify(X, y, beta, lambda_value, tolerance=tol)
        if not candidate_metrics["valid"]:
            raise FloatingPointError("Invalid primal-dual certificate")
        if state is None:
            diag = dict(gradient_evaluations=0, coordinate_updates=0,
                        linear_system_solves=0, admm_r_norm=None,
                        admm_s_norm=None, admm_eps_primal=None,
                        admm_eps_dual=None, admm_residuals_met=None)
            if algorithm == "ADMM":
                eps_abs = 1e-6 * max(1.0, float(np.sqrt(np.mean(y*y))))
                eps0 = float(np.sqrt(X.shape[1]) * eps_abs)
                diag.update(admm_r_norm=0.0, admm_s_norm=0.0,
                            admm_eps_primal=eps0, admm_eps_dual=eps0,
                            admm_residuals_met=True)
        else:
            diag = solver.diagnostics(state)
        row = {**candidate_metrics, **diag, "iteration": iteration,
               "nonzero_count": int(np.count_nonzero(np.abs(beta) > threshold)),
               "diagnostic_evaluations": evaluations, "is_final": False}
        # The checkpoint is committed only after the certificate and internal
        # diagnostics both succeed. Failed evaluations cannot publish a row or
        # replace the last valid coefficients/metrics.
        saved_beta = beta.copy()
        saved_state = _snapshot(state)
        row["elapsed_seconds"] = elapsed()
        if history and history[-1]["iteration"] == iteration:
            history[-1] = row
        else:
            history.append(row)
        metrics = candidate_metrics
        last_valid_time = row["elapsed_seconds"]
        checkpoint = dict(beta=saved_beta, state=saved_state, iteration=iteration,
                          metrics=metrics.copy(), history_length=len(history),
                          elapsed_seconds=last_valid_time, row=row.copy())
        return metrics["converged"]

    def restore_checkpoint():
        nonlocal state, beta, iteration, metrics, last_valid_time
        if checkpoint is None:
            state, beta, metrics = None, None, None
            iteration, last_valid_time = 0, None
            history.clear()
            return
        state = _snapshot(checkpoint["state"])
        beta = checkpoint["beta"].copy()
        iteration = checkpoint["iteration"]
        metrics = checkpoint["metrics"].copy()
        last_valid_time = checkpoint["elapsed_seconds"]
        del history[checkpoint["history_length"]:]
        history[-1] = checkpoint["row"].copy()

    previous = None
    try:
        beta = np.zeros(X.shape[1], dtype=np.float64)
        if evaluate():
            status, reason = "converged", "duality_gap"
            setup = history[-1]["elapsed_seconds"]
        elif elapsed() >= budget:
            status, reason = "time_limit", "wall_clock_limit"
            setup = history[-1]["elapsed_seconds"]
        else:
            stage = "initialize"
            state = solver.initialize(X, y, lambda_value, beta, config.get("algorithm_config", {}))
            setup = elapsed()
            if setup >= budget or max_iter == 0:
                stage = "evaluate"
                evaluate()
                status, reason = (("converged", "duality_gap") if metrics["converged"] else
                                  (("time_limit", "wall_clock_limit") if elapsed() >= budget else
                                   ("max_iter", "max_iterations")))
            else:
                for k in range(1, max_iter + 1):
                    attempted = k
                    previous = _snapshot(state)
                    stage = "step"
                    solver.step(state)
                    candidate = solver.current_beta(state)
                    vectors = [candidate] + [getattr(state, key) for key in ("x", "z", "u") if hasattr(state, key)]
                    if (candidate.shape != (X.shape[1],)
                            or any(not np.isfinite(v).all() for v in vectors)):
                        state = previous
                        raise FloatingPointError("Non-finite solver update")
                    beta = candidate.copy()
                    iteration = k
                    timed_out = elapsed() >= budget
                    if k % every == 0 or k == max_iter or timed_out:
                        stage = "evaluate"
                        if evaluate():
                            status, reason = "converged", "duality_gap"
                            break
                        if elapsed() >= budget:
                            status, reason = "time_limit", "wall_clock_limit"
                            break
                        if k == max_iter:
                            status, reason = "max_iter", "max_iterations"
                            break
    except Exception as exc:
        failure_traceback = traceback.format_exc()
        failure_elapsed = elapsed()
        previous_checkpoint_iteration = checkpoint["iteration"] if checkpoint is not None else None
        previous_checkpoint_time = checkpoint["elapsed_seconds"] if checkpoint is not None else None
        status = "numerical_error" if isinstance(exc, (FloatingPointError, np.linalg.LinAlgError)) else "exception"
        reason = "nonfinite" if status == "numerical_error" else "exception"
        if stage == "step" and previous is not None:
            state = previous
            beta = solver.current_beta(state).copy()
        else:
            restore_checkpoint()
        recovery_error = None
        try:
            if beta is not None:
                evaluate()
        except Exception as recovery_exc:
            recovery_error = dict(exception_type=type(recovery_exc).__name__,
                                  message=str(recovery_exc), traceback=traceback.format_exc())
            restore_checkpoint()
        error = dict(stage=stage, exception_type=type(exc).__name__, message=str(exc),
                     traceback=failure_traceback, attempted_iteration=attempted,
                     last_valid_iteration=iteration if beta is not None else None,
                     last_valid_elapsed_seconds=last_valid_time,
                     last_checkpoint_iteration=previous_checkpoint_iteration,
                     last_checkpoint_elapsed_seconds=previous_checkpoint_time,
                     failure_elapsed_seconds=failure_elapsed)
        if recovery_error is not None:
            error["recovery_error"] = recovery_error
        if history:
            history[-1]["elapsed_seconds"] = elapsed()
            history[-1]["diagnostic_evaluations"] = evaluations
    if not history and checkpoint is None:
        # An initial evaluation failure still has one auditable terminal row.
        # No valid coefficient or metric is implied by this empty checkpoint.
        status, reason = "exception", "exception"
        beta, state, metrics = None, None, None
        iteration = 0
        row = dict.fromkeys((
            "objective_value", "dual_objective", "duality_gap",
            "relative_duality_gap", "objective_scale", "dual_feasibility_violation",
            "kkt_violation", "valid", "converged", "nonzero_count",
            "admm_r_norm", "admm_s_norm", "admm_eps_primal", "admm_eps_dual",
            "admm_residuals_met",
        ))
        row.update(iteration=0, gradient_evaluations=0, coordinate_updates=0,
                   linear_system_solves=0, diagnostic_evaluations=evaluations,
                   elapsed_seconds=elapsed(), is_final=True)
        history.append(row)
    runtime = history[-1]["elapsed_seconds"] if history else elapsed()
    setup = min(runtime, setup if setup is not None else runtime)
    if history:
        history[-1]["is_final"] = True
    return SolveResult(beta, state, history, metrics, iteration, runtime, setup,
                       runtime - setup, status, reason, error)

def warmup(solver, X, y, lambda_value, algorithm_config=None):
    """At most ten updates, discarded before timed cold initialization."""
    state = solver.initialize(X, y, lambda_value, np.zeros(X.shape[1]), algorithm_config or {})
    for _ in range(10):
        solver.step(state)
