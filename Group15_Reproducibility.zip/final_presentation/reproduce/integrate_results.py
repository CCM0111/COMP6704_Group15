#!/usr/bin/env python3
"""Preserve 192 original rows and append the separately scoped 32-run supplement.

All primary result/model/config/environment files are copied byte-for-byte.
Merged path fields are presentation-relative; original CSVs remain unmodified.
No solver is run by this script. Original and supplemental models are checked
against the common arrays, which audits established are identical across teams.
"""
from __future__ import annotations
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[k]='1'
import argparse,csv,json,shutil,statistics,sys
from collections import Counter,defaultdict
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'reproduce/library'))
import numpy as np
from threadpoolctl import threadpool_limits
from common.data import sha256_file
from common.metrics import certify,original_unit_metrics
from common.schemas import SUMMARY_COLUMNS,CONVERGENCE_COLUMNS,cell
EXTRA=['owner','evidence_scope','source_file','source_sha256','environment_file','host_label']
OWNERS={'ISTA':'Member A','FISTA':'Member B','CD':'Member C','ADMM':'Member D'}


def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


def rows(path):
    with path.open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))


def write_csv(path,columns,data):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,columns,lineterminator='\n');w.writeheader()
        for row in data:w.writerow({k:cell(row.get(k)) for k in columns})


def capture_originals():
    project=BASE.parent
    specifications={
        'ISTA':(BASE/'_audit/ISTA/extracted/lasso_A', 'member_A_ISTA/results/dev-20261024-ista-local01','lasso_A_ISTA.zip'),
        'FISTA':(BASE/'_audit/FISTA/lasso_B', 'member_B_FISTA/results/dev-20261023-fista-local01','lasso_B.zip'),
        'CD':(BASE/'_audit/CD/lasso_project', 'member_C_CD/results/dev-20261023-cd-local01','lasso_project_CD.zip'),
        'ADMM':(project, 'member_D_ADMM/results/dev-20261022-admm-v3',None)}
    catalog=[];file_manifest=[]
    for alg,(source_root,relative,archive) in specifications.items():
        campaign=source_root/relative
        if not (campaign/'summary.csv').exists():raise FileNotFoundError('Initial source collection needs '+str(campaign))
        dest=BASE/'analysis/source_data'/alg/campaign.name
        to_copy=[p for p in campaign.rglob('*') if p.is_file() and
            ((p.parent==campaign and p.name in ('summary.csv','convergence.csv','aggregate.csv','environment.json','validation_report.json'))
              or ('runs' in p.relative_to(campaign).parts and p.suffix in ('.json','.npz')))]
        for p in to_copy:
            d=dest/p.relative_to(campaign);d.parent.mkdir(parents=True,exist_ok=True)
            if d.exists() and d.read_bytes()!=p.read_bytes():raise ValueError('Preserved source changed: '+str(d))
            shutil.copyfile(p,d)
            file_manifest.append(dict(file=d.relative_to(BASE).as_posix(),original_file=str(p.relative_to(project)),sha256=sha256_file(d)))
        # Preserve the original frozen configuration and reference certificates,
        # without four duplicate copies of identical feature arrays or figures.
        for folder in ('configs','references'):
            for p in (source_root/folder).rglob('*'):
                if p.is_file() and p.suffix in ('.json','.npz'):
                    d=dest/'source_inputs'/folder/p.relative_to(source_root/folder);d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
                    file_manifest.append(dict(file=d.relative_to(BASE).as_posix(),original_file=str(p.relative_to(project)),sha256=sha256_file(d)))
        catalog.append(dict(algorithm=alg,owner=OWNERS[alg],campaign=campaign.name,
            copied_campaign=dest.relative_to(BASE).as_posix(),original_campaign=str(campaign.relative_to(project)),
            archive=archive,archive_sha256=sha256_file(project/archive) if archive else None))
    dump(BASE/'analysis/source_data/source_catalog.json',{'sources':catalog,'files':file_manifest,
        'scope':'Original participant submissions; snapshots copied once, no figures or duplicate merged exports included'})
    return catalog,file_manifest


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--supplement',default='analysis/supplement',help='Supplement directory relative to presentation root')
    args=p.parse_args()
    cat_path=BASE/'analysis/source_data/source_catalog.json'
    if cat_path.exists():
        c=json.loads(cat_path.read_text());catalog,file_manifest=c['sources'],c['files']
    else:catalog,file_manifest=capture_originals()
    for f in file_manifest:
        if sha256_file(BASE/f['file'])!=f['sha256']:raise ValueError('Source evidence hash mismatch: '+f['file'])
    merged=[];convergence=[];envs={}
    for source in catalog:
        campaign=BASE/source['copied_campaign'];envfile=campaign/'environment.json';env=json.loads(envfile.read_text())
        envs[source['algorithm']]=env
        for filename,collection in [('summary.csv',merged),('convergence.csv',convergence)]:
            path=campaign/filename;data=rows(path)
            if filename=='summary.csv' and len(data)!=48:raise ValueError(source['algorithm']+' must have exactly 48 original rows')
            for r in data:
                if filename=='summary.csv':
                    for key in ('config_file','solution_file','error_file'):
                        if r.get(key):r[key]=(campaign/r[key]).relative_to(BASE).as_posix()
                r.update(owner=source['owner'],evidence_scope='original',source_file=path.relative_to(BASE).as_posix(),
                    source_sha256=sha256_file(path),environment_file=envfile.relative_to(BASE).as_posix(),host_label=env['cpu_model'])
                collection.append(r)
    if len(merged)!=192:raise ValueError('Original result completeness must be 192')
    supplement=(BASE/args.supplement).resolve()
    if not supplement.is_relative_to(BASE):raise ValueError('Supplement path must stay in presentation directory')
    envfile=supplement/'environment.json';env=json.loads(envfile.read_text());envs['same_machine_supplement']=env
    for filename,collection in [('Supplemental_Results.csv',merged),('Supplemental_Convergence.csv',convergence)]:
        path=supplement/filename;data=rows(path)
        if filename=='Supplemental_Results.csv' and len(data)!=32:raise ValueError('Focused supplement must have exactly 32 rows')
        for r in data:
            r.update(evidence_scope='same_machine_supplement',source_file=path.relative_to(BASE).as_posix(),
                source_sha256=sha256_file(path),environment_file=envfile.relative_to(BASE).as_posix(),host_label=env['cpu_model'])
            collection.append(r)
    if len({r['run_id'] for r in merged})!=224:raise ValueError('Duplicate/missing run IDs in merged evidence')
    pair_keys=[(r['run_id'],r['iteration']) for r in convergence]
    if len(set(pair_keys))!=len(pair_keys):raise ValueError('Duplicate checkpoint key')
    arrays={}
    for did in ('DIA','S100','S200','S400'):
        with np.load(BASE/'reproduce/inputs/dev_assets/datasets'/did/'data.npz',allow_pickle=False) as z:
            arrays[did]={k:z[k] for k in z.files}
    verification=[];maxdiff=defaultdict(float)
    for r in merged:
        with np.load(BASE/r['solution_file'],allow_pickle=False) as z:beta=z['beta']
        a=arrays[r['dataset_id']];lam=float(r['lambda']);m=certify(a['X_train'],a['y_train'],beta,lam)
        prediction=original_unit_metrics(a['X_train'],a['X_test'],a['y_train_raw'],a['y_test_raw'],float(a['y_mean']),beta,float(r['nonzero_threshold']),a.get('beta_true_std'))
        expected=dict(final_objective=m['objective_value'],**{k:m[k] for k in ('duality_gap','relative_duality_gap','dual_feasibility_violation','kkt_violation')},**prediction)
        mismatch=[]
        for k,v in expected.items():
            if v is None:
                if r[k]!='':mismatch.append(k)
            else:
                diff=abs(float(r[k])-v);maxdiff[k]=max(maxdiff[k],diff)
                if not np.isclose(float(r[k]),v,rtol=1e-8,atol=1e-9):mismatch.append(k)
        og=m['objective_value']-float(r['reference_objective'])
        if not og>=-5e-10*float(r['objective_scale']):mismatch.append('objective_below_reference')
        passed=m['valid'] and m['converged'] and not mismatch
        verification.append(dict(run_id=r['run_id'],algorithm=r['algorithm'],evidence_scope=r['evidence_scope'],passed=bool(passed),
            mismatches=mismatch,relative_duality_gap=m['relative_duality_gap'],test_rmse=prediction['test_rmse']))
    write_csv(BASE/'analysis/Merged_Results.csv',SUMMARY_COLUMNS+EXTRA,merged)
    write_csv(BASE/'analysis/Convergence_Results.csv',CONVERGENCE_COLUMNS+EXTRA,convergence)
    dump(BASE/'analysis/model_recomputation.json',dict(solvers_rerun=False,model_count=len(verification),
        all_passed=all(v['passed'] for v in verification),maximum_absolute_metric_discrepancies=dict(maxdiff),checks=verification))
    grouped=defaultdict(list)
    for r in merged:grouped[(r['evidence_scope'],r['experiment_id'],r['algorithm'])].append(r)
    aggregates=[]
    for (scope,eid,alg),rr in sorted(grouped.items()):
        timing=[x for x in rr if x['mode']=='timing'];trace=next(x for x in rr if x['mode']=='trace')
        times=[float(x['runtime_seconds']) for x in timing];setups=[float(x['setup_seconds']) for x in timing];solves=[float(x['solve_seconds']) for x in timing]
        aggregates.append(dict(evidence_scope=scope,experiment_id=eid,algorithm=alg,dataset_id=trace['dataset_id'],host_label=trace['host_label'],
            environment_id=trace['environment_id'],lambda_value=float(trace['lambda']),lambda_ratio=float(trace['lambda_ratio']),n_features=int(trace['n_features']),
            trace_iterations=int(trace['iterations']),timing_iterations=[int(x['iterations']) for x in timing],timing_repeats=len(timing),
            runtime_mean_seconds=statistics.mean(times),runtime_sample_std_seconds=statistics.stdev(times),runtime_median_seconds=statistics.median(times),runtime_min_seconds=min(times),runtime_max_seconds=max(times),
            runtime_q25_seconds=float(np.quantile(times,.25)),runtime_q75_seconds=float(np.quantile(times,.75)),
            setup_median_seconds=statistics.median(setups),solve_median_seconds=statistics.median(solves),
            final_objective=float(trace['final_objective']),relative_duality_gap=float(trace['relative_duality_gap']),
            train_rmse=float(trace['train_rmse']),test_rmse=float(trace['test_rmse']),nonzero_count=int(trace['nonzero_count']),
            sparsity_ratio=float(trace['sparsity_ratio']),support_precision=float(trace['support_precision']) if trace['support_precision'] else None,
            support_recall=float(trace['support_recall']) if trace['support_recall'] else None,
            support_f1=float(trace['support_f1']) if trace['support_f1'] else None,
            coef_relative_error=float(trace['coef_relative_error']) if trace['coef_relative_error'] else None,
            all_converged=all(x['convergence_status']=='converged' for x in rr),validation_statuses=dict(Counter(x['validation_status'] for x in rr))))
    compact_env={name:{k:env.get(k) for k in ('cpu_model','physical_cores','logical_cores','ram_bytes','python_version','packages','environment_id','threads','git_commit')} for name,env in envs.items()}
    summary=dict(total_summary_rows=len(merged),original_rows=192,same_machine_supplement_rows=32,convergence_rows=len(convergence),
        scopes=dict(Counter(r['evidence_scope'] for r in merged)),statuses=dict(Counter(r['convergence_status'] for r in merged)),
        all_saved_models_independently_recomputed=all(v['passed'] for v in verification),failed_model_checks=[v for v in verification if not v['passed']],
        original_comparison_scope='Numerical outcomes on identical arrays; original wall-clock timings must remain per-host and cannot establish a fair cross-method ranking.',
        supplemental_comparison_scope='E01/E02 only, all four exact submitted solvers in one process/machine with one frozen runner, cyclic order, cold setup, requested BLAS single-thread, 1trace+3timing each; not the formal 12-problem 192-run comparison.',
        artifacts={'merged_results':'analysis/Merged_Results.csv','convergence':'analysis/Convergence_Results.csv','independent_model_checks':'analysis/model_recomputation.json'},
        environments=compact_env,aggregates=aggregates,
        field_contract={'summary':SUMMARY_COLUMNS+EXTRA,'convergence':CONVERGENCE_COLUMNS+EXTRA,'paths':'All path fields in merged outputs are relative to final_presentation; original source CSV files are byte-for-byte preserved.'})
    dump(BASE/'analysis/results_summary.json',summary)
    print(json.dumps({k:summary[k] for k in ('total_summary_rows','original_rows','same_machine_supplement_rows','convergence_rows','statuses','all_saved_models_independently_recomputed')},indent=2))
    if not summary['all_saved_models_independently_recomputed']:raise SystemExit('Some saved-model checks failed; inspect analysis/model_recomputation.json')

if __name__=='__main__':
    with threadpool_limits(limits=1):main()
