"""Protocol 1.0.0 FISTA: constant-step accelerated proximal gradient."""
from dataclasses import dataclass
import numpy as np
from scipy.linalg import eigvalsh


def soft_threshold(v, threshold):
    return np.sign(v) * np.maximum(np.abs(v) - threshold, 0.0)


@dataclass
class State:
    X: np.ndarray
    y: np.ndarray
    lambda_value: float
    L: float
    step_size: float
    beta: np.ndarray
    v: np.ndarray
    t: float
    gradient_evaluations: int = 0
    t_initial: float = 1.0


def initialize(X, y, lambda_value, beta0, algorithm_config):
    expected = dict(L_method='gram_eigvalsh', restart=False,
                    backtracking=False, t_initial=1.0)
    if algorithm_config != expected:
        raise ValueError('Only the frozen constant-step FISTA configuration is supported')
    n, d = X.shape
    gram = (X.T @ X) / n
    largest = float(eigvalsh(gram, subset_by_index=[d - 1, d - 1])[0])
    del gram
    if not np.isfinite(largest) or largest <= 0.0:
        raise FloatingPointError('Invalid Gram eigenvalue for FISTA step size')
    L = (1.0 + 1e-12) * largest
    beta = beta0.copy()
    return State(X, y, lambda_value, L, 1.0 / L, beta, beta.copy(), 1.0)


def step(state):
    """One outer FISTA update; beta is reported, v is extrapolation only."""
    n = state.X.shape[0]
    Xv = state.X @ state.v
    gradient = state.X.T @ (Xv - state.y) / n
    beta_next = soft_threshold(state.v - state.step_size * gradient,
                               state.lambda_value * state.step_size)
    t_next = 0.5 * (1.0 + np.sqrt(1.0 + 4.0 * state.t * state.t))
    momentum = (state.t - 1.0) / t_next
    v_next = beta_next + momentum * (beta_next - state.beta)
    state.beta = beta_next
    state.v = v_next
    state.t = t_next
    state.gradient_evaluations += 1
    if not state_is_finite(state):
        raise FloatingPointError('Nonfinite FISTA state')


def current_beta(state):
    return state.beta


def state_is_finite(state):
    return bool(np.isfinite(state.beta).all() and np.isfinite(state.v).all()
                and np.isfinite(state.t) and np.isfinite(state.L)
                and np.isfinite(state.step_size))


def diagnostics(state):
    return dict(gradient_evaluations=state.gradient_evaluations,
                extrapolation_updates=state.gradient_evaluations,
                L_value=float(state.L), step_size=float(state.step_size),
                t_initial=float(state.t_initial), t_final=float(state.t),
                sweeps=0, coordinate_updates=0, linear_system_solves=0,
                degenerate_columns=[])
