"""Protocol 1.0.0 ADMM for ||X beta-y||^2/(2n) + lambda ||beta||_1.

Only setup and one outer update live here. The common runner owns timing,
primal-dual certification, stopping, and output. In particular, residuals below
their ADMM thresholds are diagnostic and never cause this module to stop.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import math
from numbers import Real
from typing import Any

import numpy as np
from scipy.linalg import cho_factor, cho_solve, norm


ALGORITHM = "ADMM"
RHO = 1.0
RELAXATION = 1.0
EPS_REL = 1e-4


@dataclass
class State:
    """One cold run, including its cached normal equations and factorization.

    ``G``, ``q``, ``system`` and ``cholesky`` are computed once per initialize.
    ``last_rhs`` permits an independent linear-system residual check. No input
    data, solution or factorization is reused across calls to initialize.
    """

    n: int
    d: int
    lambda_value: float
    rho: float
    relaxation: float
    eps_abs: float
    eps_rel: float
    G: np.ndarray
    q: np.ndarray
    system: np.ndarray
    cholesky: tuple[np.ndarray, bool]
    x: np.ndarray
    z: np.ndarray
    u: np.ndarray
    last_rhs: np.ndarray
    iteration: int = 0
    admm_r_norm: float = 0.0
    admm_s_norm: float = 0.0
    admm_eps_primal: float = 0.0
    admm_eps_dual: float = 0.0
    admm_residuals_met: bool = True

    @property
    def factorization(self) -> tuple[np.ndarray, bool]:
        """Expose the cached SciPy factorization for inspection without copying."""
        return self.cholesky


def _real_scalar(value: Any, name: str, *, positive: bool) -> float:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real scalar")
    result = float(value)
    if not math.isfinite(result) or (result <= 0 if positive else result < 0):
        relation = "positive" if positive else "nonnegative"
        raise ValueError(f"{name} must be finite and {relation}")
    return result


def soft_threshold(values: Any, threshold: float) -> np.ndarray:
    """Return sign(v) * max(abs(v) - threshold, 0), without changing v."""
    tau = _real_scalar(threshold, "threshold", positive=False)
    source = np.asarray(values)
    if source.dtype.kind not in "fiu":
        raise TypeError("values must contain real numbers")
    array = np.asarray(source, dtype=np.float64)
    if not np.isfinite(array).all():
        raise ValueError("values must be finite")
    return np.asarray(np.sign(array) * np.maximum(np.abs(array) - tau, 0.0))


def _validate_array(value: Any, name: str, ndim: int) -> np.ndarray:
    if not isinstance(value, np.ndarray):
        raise TypeError(f"{name} must be a numpy.ndarray")
    if value.dtype != np.float64:
        raise TypeError(f"{name} must have dtype float64")
    if value.ndim != ndim:
        raise ValueError(f"{name} must have {ndim} dimensions")
    if not np.isfinite(value).all():
        raise ValueError(f"{name} must contain only finite values")
    return value


def _rms(y: np.ndarray) -> float:
    # Equivalent to sqrt(mean(y**2)); rescaling avoids needless overflow.
    scale = float(np.max(np.abs(y)))
    return 0.0 if scale == 0 else scale * math.sqrt(float(np.mean((y / scale) ** 2)))


def _validate_config(config: Mapping[str, Any] | None, eps_abs: float) -> None:
    if config is None:
        return
    if not isinstance(config, Mapping):
        raise TypeError("algorithm_config must be a mapping or None")
    expected = {
        "rho": RHO,
        "relaxation": RELAXATION,
        "adaptive_rho": False,
        "linear_solver": "scipy_cho_solve",
        "eps_abs": eps_abs,
        "eps_rel": EPS_REL,
    }
    unknown = set(config) - set(expected)
    if unknown:
        raise ValueError(f"unsupported ADMM parameters: {sorted(unknown, key=str)}")
    for key, value in config.items():
        if key == "adaptive_rho":
            if not isinstance(value, (bool, np.bool_)) or bool(value):
                raise ValueError("protocol requires adaptive_rho=false")
        elif key == "linear_solver":
            if not isinstance(value, str) or value != expected[key]:
                raise ValueError("protocol requires linear_solver='scipy_cho_solve'")
        else:
            actual = _real_scalar(value, key, positive=True)
            target = float(expected[key])
            # Allow only roundoff in the independently computed y RMS.
            allowed = key == "eps_abs" and math.isclose(actual, target, rel_tol=2e-15)
            if actual != target and not allowed:
                raise ValueError(f"protocol requires {key}={target!r}")


def initialize(
    X: np.ndarray,
    y: np.ndarray,
    lambda_value: float,
    beta0: np.ndarray,
    algorithm_config: Mapping[str, Any] | None = None,
) -> State:
    """Allocate a cold state and cache G, q and one Cholesky factorization.

    The public loader supplies float64 arrays (X in Fortran order). This
    function accepts either contiguous layout for small standalone tests, but
    never changes preprocessing, centers y, adds an intercept, or rescales lambda.
    A nonzero beta0 is rejected because the mandatory protocol is cold-started.
    """
    X = _validate_array(X, "X", 2)
    y = _validate_array(y, "y", 1)
    beta0 = _validate_array(beta0, "beta0", 1)
    n, d = X.shape
    if n == 0 or d == 0:
        raise ValueError("X must have positive sample and feature dimensions")
    if y.shape != (n,):
        raise ValueError("y shape must match X sample count")
    if beta0.shape != (d,):
        raise ValueError("beta0 shape must match X feature count")
    if np.any(beta0 != 0):
        raise ValueError("protocol requires beta0=0 and x=z=u=0")
    lam = _real_scalar(lambda_value, "lambda_value", positive=True)
    eps_abs = 1e-6 * max(1.0, _rms(y))
    _validate_config(algorithm_config, eps_abs)

    # All algorithm-specific precomputation belongs inside initialize, so the
    # runner includes it in setup_seconds. Never use an explicit inverse.
    with np.errstate(over="raise", invalid="raise", divide="raise"):
        G = X.T @ X / n
        q = X.T @ y / n
        system = G.copy()
        system.flat[:: d + 1] += RHO
    if not (np.isfinite(G).all() and np.isfinite(q).all() and np.isfinite(system).all()):
        raise FloatingPointError("nonfinite ADMM normal equations")
    factor = cho_factor(system, lower=True, overwrite_a=False, check_finite=False)
    # The unused triangle from cho_factor is unspecified. Check only L.
    if not np.isfinite(np.tril(factor[0])).all():
        raise FloatingPointError("nonfinite ADMM Cholesky factor")
    eps_initial = math.sqrt(d) * eps_abs
    return State(
        n=n,
        d=d,
        lambda_value=lam,
        rho=RHO,
        relaxation=RELAXATION,
        eps_abs=eps_abs,
        eps_rel=EPS_REL,
        G=G,
        q=q,
        system=system,
        cholesky=factor,
        x=np.zeros(d, dtype=np.float64),
        z=np.zeros(d, dtype=np.float64),
        u=np.zeros(d, dtype=np.float64),
        last_rhs=q.copy(),
        admm_eps_primal=eps_initial,
        admm_eps_dual=eps_initial,
    )


def step(state: State) -> None:
    """Complete one ADMM update, committing only a fully finite new state.

    If the solve or any diagnostic fails, the previous valid x/z/u, iteration,
    residuals and right-hand side remain available to the runner for audit.
    """
    if not isinstance(state, State):
        raise TypeError("state must be an ADMM State")
    with np.errstate(over="raise", invalid="raise", divide="raise"):
        rhs = state.q + state.rho * (state.z - state.u)
        if not np.isfinite(rhs).all():
            raise FloatingPointError("nonfinite ADMM right-hand side")
        x_new = cho_solve(state.cholesky, rhs, overwrite_b=False, check_finite=False)
        if not np.isfinite(x_new).all():
            raise FloatingPointError("nonfinite ADMM linear-system solution")
        threshold_input = x_new + state.u
        z_new = np.sign(threshold_input) * np.maximum(
            np.abs(threshold_input) - state.lambda_value / state.rho, 0.0
        )
        r = x_new - z_new
        s = state.rho * (z_new - state.z)
        u_new = state.u + r
        r_norm = float(norm(r, check_finite=False))
        s_norm = float(norm(s, check_finite=False))
        eps_primal = math.sqrt(state.d) * state.eps_abs + state.eps_rel * max(
            float(norm(x_new, check_finite=False)), float(norm(z_new, check_finite=False))
        )
        eps_dual = math.sqrt(state.d) * state.eps_abs + state.eps_rel * float(
            norm(state.rho * u_new, check_finite=False)
        )
    if not (
        np.isfinite(z_new).all()
        and np.isfinite(u_new).all()
        and all(math.isfinite(v) for v in (r_norm, s_norm, eps_primal, eps_dual))
    ):
        raise FloatingPointError("nonfinite ADMM update or residual diagnostic")

    state.x, state.z, state.u = x_new, z_new, u_new
    state.last_rhs = rhs
    state.iteration += 1
    state.admm_r_norm = r_norm
    state.admm_s_norm = s_norm
    state.admm_eps_primal = eps_primal
    state.admm_eps_dual = eps_dual
    state.admm_residuals_met = r_norm <= eps_primal and s_norm <= eps_dual


def current_beta(state: State) -> np.ndarray:
    """Return the original-problem coefficient z; callers must not mutate it."""
    return state.z


def diagnostics(state: State) -> dict[str, Any]:
    """Protocol counters and split residuals, with no public gap evaluation."""
    return {
        "gradient_evaluations": 0,
        "coordinate_updates": 0,
        "linear_system_solves": state.iteration,
        "admm_r_norm": state.admm_r_norm,
        "admm_s_norm": state.admm_s_norm,
        "admm_eps_primal": state.admm_eps_primal,
        "admm_eps_dual": state.admm_eps_dual,
        "admm_residuals_met": state.admm_residuals_met,
    }
