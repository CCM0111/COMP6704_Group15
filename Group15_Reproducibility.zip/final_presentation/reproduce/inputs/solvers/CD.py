"""Protocol 1.0.0 cyclic coordinate descent; one step is one full sweep."""
from dataclasses import dataclass
import numpy as np


def soft_threshold(v, threshold):
    return np.sign(v) * np.maximum(np.abs(v) - threshold, 0.0)


@dataclass
class State:
    X: np.ndarray
    y: np.ndarray
    lambda_value: float
    beta: np.ndarray
    residual: np.ndarray
    column_norms: np.ndarray
    degenerate_columns: np.ndarray
    sweeps: int = 0


def initialize(X, y, lambda_value, beta0, algorithm_config):
    if algorithm_config != dict(selection='cyclic', refresh_every_sweeps=10, screening=False):
        raise ValueError('Only the frozen cyclic CD configuration is supported')
    a = np.einsum('ij,ij->j', X, X) / len(y)
    beta = beta0.copy()
    return State(X, y, lambda_value, beta, y-X@beta, a, np.flatnonzero(a <= 1e-24))


def step(state):
    n, d = state.X.shape
    for j in range(d):
        x = state.X[:, j]
        old = state.beta[j]
        a = state.column_norms[j]
        if a <= 1e-24:
            new = 0.0
        else:
            # Algebraically x.T@(r+x*old)/n, without allocating that temporary.
            v = float(x @ state.residual) / n + a * old
            new = float(np.sign(v) * max(abs(v)-state.lambda_value, 0.0) / a)
        state.beta[j] = new
        state.residual -= x * (new-old)
    state.sweeps += 1
    if state.sweeps % 10 == 0:
        state.residual[:] = state.y-state.X@state.beta


def current_beta(state):
    return state.beta


def diagnostics(state):
    return dict(sweeps=state.sweeps, coordinate_updates=state.sweeps*state.X.shape[1],
                gradient_evaluations=0, linear_system_solves=0,
                degenerate_columns=state.degenerate_columns.tolist())
