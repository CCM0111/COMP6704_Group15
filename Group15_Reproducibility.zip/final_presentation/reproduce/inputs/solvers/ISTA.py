"""Member A: protocol 1.0.0 ISTA (constant-step proximal gradient).

The iteration is implemented here; neither sklearn nor scipy optimizers
are used to update beta. scipy.linalg.eigvalsh is used for the frozen setup.
"""
from dataclasses import dataclass
import numpy as np
from scipy.linalg import eigvalsh


def soft_threshold(values, threshold):
    """Proximal operator of threshold * ||beta||_1."""
    return np.sign(values) * np.maximum(np.abs(values) - threshold, 0.0)


@dataclass
class State:
    X: np.ndarray
    y: np.ndarray
    lambda_value: float
    L: float
    step_size: float
    beta: np.ndarray
    gradient_evaluations: int = 0


def initialize(X, y, lambda_value, beta0, algorithm_config):
    expected = dict(L_method='gram_eigvalsh', restart=False, backtracking=False)
    if algorithm_config != expected:
        raise ValueError('Only the frozen ISTA configuration is supported')
    X = np.asarray(X, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    beta0 = np.asarray(beta0, dtype=np.float64)
    if X.ndim != 2 or y.shape != (X.shape[0],) or beta0.shape != (X.shape[1],):
        raise ValueError('Invalid X/y/beta0 shapes')
    if not np.isfinite(X).all() or not np.isfinite(y).all() or not np.isfinite(beta0).all():
        raise ValueError('Nonfinite initial data')
    if not np.isfinite(lambda_value) or lambda_value <= 0.0:
        raise ValueError('lambda_value must be finite and positive')
    n, d = X.shape
    # All work below is timed as setup by the shared runner.
    gram = (X.T @ X) / n
    largest = float(eigvalsh(gram, subset_by_index=[d - 1, d - 1])[0])
    del gram
    if not np.isfinite(largest) or largest <= 0.0:
        raise FloatingPointError('Invalid largest Gram eigenvalue for ISTA step size')
    L = (1.0 + 1e-12) * largest
    return State(X=X, y=y, lambda_value=float(lambda_value), L=L,
                 step_size=1.0 / L, beta=beta0.copy())


def step(state):
    """One COMPLETE proximal-gradient update, counting one X and one X.T matvec."""
    n = state.X.shape[0]
    gradient = state.X.T @ (state.X @ state.beta - state.y) / n
    next_beta = soft_threshold(state.beta - state.step_size * gradient,
                               state.lambda_value * state.step_size)
    state.beta = next_beta
    state.gradient_evaluations += 1
    if not state_is_finite(state):
        raise FloatingPointError('Nonfinite ISTA state')


def current_beta(state):
    return state.beta


def state_is_finite(state):
    return bool(np.isfinite(state.beta).all() and np.isfinite(state.L)
                and np.isfinite(state.step_size))


def diagnostics(state):
    return dict(gradient_evaluations=state.gradient_evaluations,
                L_value=float(state.L), step_size=float(state.step_size),
                sweeps=0, coordinate_updates=0, linear_system_solves=0,
                degenerate_columns=[])
