#!/usr/bin/env python3
"""Generate portable analysis notes from the merged numeric evidence; no runs."""
from pathlib import Path
import csv,json,shutil,statistics,hashlib
from collections import defaultdict
BASE=Path(__file__).resolve().parents[1]
PROJECT=BASE.parent
A=BASE/'analysis'
summary=json.loads((A/'results_summary.json').read_text())
rows=list(csv.DictReader((A/'Merged_Results.csv').open()))
history=list(csv.DictReader((A/'Convergence_Results.csv').open()))
catalog=json.loads((A/'source_data/source_catalog.json').read_text())['sources']
input_manifest=json.loads((BASE/'reproduce/input_manifest.json').read_text())


def write(name,lines):
    (A/name).write_text('\n'.join(lines)+'\n',encoding='utf-8')


def table(headers,body):
    return ['| '+' | '.join(headers)+' |','|'+'|'.join('---' for _ in headers)+'|']+['| '+' | '.join(map(str,r))+' |' for r in body]


def grouped(scope,eid,alg):
    return next(g for g in summary['aggregates'] if g['evidence_scope']==scope and g['experiment_id']==eid and g['algorithm']==alg)


# Copies are exact evidence snapshots. Absolute path strings in the historical
# audit content identify its original machine; the index supplies portable paths.
auditdir=A/'audits';auditdir.mkdir(exist_ok=True)
audit_sources=[(BASE/'_audit/ISTA/ISTA_audit.md','ISTA_audit.md'),(BASE/'_audit/ISTA/ISTA_audit.json','ISTA_audit.json'),
    (BASE/'_audit/FISTA_audit.md','FISTA_audit.md'),(BASE/'_audit/FISTA_audit.json','FISTA_audit.json'),
    (BASE/'_audit/CD_audit.md','CD_audit.md'),(BASE/'_audit/CD_audit.json','CD_audit.json'),
    (PROJECT/'member_D_ADMM/results/dev-20261022-admm-v3/validation_report.json','ADMM_validation_report.json')]
audit_index=[]
old_index_path=auditdir/'index.json'
old_index=json.loads(old_index_path.read_text()).get('files',[]) if old_index_path.exists() else []
old_origins={Path(e['file']).name:e['historical_source'] for e in old_index}
for source,name in audit_sources:
    dest=auditdir/name
    if source.exists():
        shutil.copyfile(source,dest)
    if dest.exists():
        audit_index.append(dict(file='analysis/audits/'+name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),historical_source=old_origins.get(name,str(source.relative_to(PROJECT)))))
(auditdir/'index.json').write_text(json.dumps({'files':audit_index,'note':'Historical audit path strings are retained as provenance identifiers. Portable source/result locations are listed in README.md.'},ensure_ascii=False,indent=2)+'\n')
(auditdir/'README.md').write_text('# Portable audit index\n\nThe copied reports retain historical source paths; these do not need to exist on the recipient machine. The active portable evidence is:\n\n- Exact four solvers: `../../reproduce/inputs/solvers/`\n- Exact shared runner/evaluator: `../../reproduce/library/common/`\n- Frozen common arrays/configs/references: `../../reproduce/inputs/dev_assets/`\n- Original byte-preserved CSVs, configurations, models and environments: `../source_data/`\n- New same-machine campaign: `../supplement/`\n- Independent recomputation of every saved model: `../model_recomputation.json`\n\n`index.json`, `../source_data/source_catalog.json` and `../../reproduce/input_manifest.json` retain SHA-256 identities. No extracted participant environment, .git directory, or old figure folder is needed to reproduce the numeric integration.\n')

sources=[]
for s in catalog:
    archive=s['archive'] or '原 ADMM 项目（非新 ZIP）'
    sources.append([s['algorithm'],archive,s['campaign'],'48',s['copied_campaign']+'/summary.csv'])
lines=['# Integration Audit','', '本次先审计三个 ZIP 和现有 ADMM 项目，保持提交源码与原始结果不变；然后用四份原求解器字节拷贝和一个公共 runner，新增 E01/E02 的32次同机补充。审计阶段仅重算保存模型，补充阶段才执行新的优化迭代。','', '## 文件与来源','']
lines+=table(['方法','提交来源','原批次','summary 行数','可移植原始CSV'],sources)
lines+=['','原 CSV 与每次运行的 config、模型、environment、validation report 已按字节保存于 `source_data/`；不复制重复 merged_results 或原有图片。各副本SHA-256及原路径见 `source_data/source_catalog.json`。三个原 ZIP 未修改，其哈希也记录在该清单中。','', '## 独立核验结果','', '- 原始 summary 合计192条；新增同机32条；合并共224条、7721个唯一轨迹检查点。224条均记录收敛，保存系数独立重算也全部通过，无未达精度的运行被隐藏。','- 三份成员审计逐数组对照确认：DIA/S100/S200/S400 的训练/测试特征、响应、原始响应、训练统计量、行号和合成真值与 ADMM 开发输入完全相同；NPZ SHA-256也相同。','- 冻结12配置的实际λ相同，E11/E12复制E02的绝对λ。参考解均经独立证书认证；参考目标是高精度数值参考值，未称为已知精确最优值。','- 所有224份保存β在共有数组上重算目标、通用primal-dual gap、对偶可行性、KKT、原单位RMSE、稀疏度和支撑指标。结果见 `model_recomputation.json`，没有重跑192条原实验来代替提交证据。','- 新增32次包括每次运行的实际 config、模型、真实环境、源码身份、顺序和独立检查：`supplement/verification_report.json`。','- 每个原包自己的单元测试报告保留为历史证据；本次未把它们冒充为新执行的测试。ADMM原验证报告明确 `formal_comparison_complete=false`。','', '## 原实现与统一接入','']
lines+=table(['方法','保持的主参数','一次外层更新'],[
 ['ISTA','L=Gram最大特征值×(1+1e-12)，无回溯/筛选/暖启动','一次完整近端梯度更新'],
 ['FISTA','同样L；t0=1；无重启/回溯/筛选/暖启动','近端梯度+标准动量；报告β而非外推点'],
 ['CD','cyclic，10 sweeps刷新一次残差，无筛选','按固定列顺序完成一轮d个坐标'],
 ['ADMM','ρ=1，relaxation=1，无adaptive rho，Cholesky求解；eps_rel=1e-4','一次x/z/u完整更新，返回z']])
lines+=['','求解器源均按原字节复制到 `../reproduce/inputs/solvers/`，只用 importlib 的独立模块名加载；没有更改公式、梯度缓存方式、参数或阈值。适配仅向各实现传入其严格要求的配置键。统一runner/evaluator等精确快照位于 `../reproduce/library/common/`。输入与库哈希见 `../reproduce/input_manifest.json`，实际运行身份见 `supplement/source_identities.json`。','', '## 合并约定','', '`Merged_Results.csv` 保留协议55列，`Convergence_Results.csv` 保留协议29列；都追加 `owner,evidence_scope,source_file,source_sha256,environment_file,host_label`。','', '`evidence_scope=original` 恰好192条；`same_machine_supplement` 恰好32条。`source_sha256` 是对应不可变主CSV文件字节哈希。合并CSV中的模型/config/environment路径相对于 `final_presentation/`；原始CSV保持原有相对路径，使用其所在campaign目录解释。Supplemental主CSV的自身哈希单元格为空，避免自指哈希；它们的实际哈希记录在验证报告，且已经填入合并派生CSV。','', '## 证据边界','', '原包来自多台机器，ISTA原Python为3.13.5；部分包git_commit为空。Mac的threadpoolctl返回空列表，环境变量记录单线程请求但没有观测到实际BLAS工作线程数；NumPy构建配置报告Accelerate。新增同机补充同样保留这一限制。全部结果均不能宣称是共同冻结commit上的完整正式192次同机比较。','', '可移植审计索引：`audits/README.md`。统计与解释边界见 `Experiment_Comparability.md`，可引用结果见 `Results_Summary.md`。']
write('Integration_Audit.md',lines)

hostrows=[]
for alg in ('ISTA','FISTA','CD','ADMM','same_machine_supplement'):
    e=summary['environments'][alg];label='新增32次补充' if alg=='same_machine_supplement' else alg+'原包'
    hostrows.append([label,e['cpu_model'],e['physical_cores'],f"{e['ram_bytes']/1024**3:g} GiB",e['python_version'], '有观测记录' if e['threads']['observed'] else '未由threadpoolctl暴露'])
lines=['# Experiment Comparability','', '原192条适合检查四种实现是否求解了同一个问题，并讨论正则化、支撑与各机器本地变化；跨方法速度比较采用单独标注的E01/E02同机32次补充。两类证据不可混为一个正式批次。','', '## 共同数学问题与数据','', '`P(β)=||Xβ-y||²/(2n)+λ||β||₁`，n为训练样本数。λ>0，无L2、样本权重、正系数限制。所有求解器不另拟合截距。','', '先划分，再仅用训练样本拟合每列均值与总体标准差（ddof=0）；标准差<1e-12的列scale=1。y只减训练均值，不缩放。预测使用 `y_mean+X_processed@β`；原特征系数为 `β/x_scale`，截距为 `y_mean-x_mean@(β/x_scale)`。测试集应用训练统计量，不重新拟合。X是float64/F-order，y为一维float64，索引int64。','', 'Diabetes使用scaled=False，442行，训练353/测试89。合成AR(1) master1250×400、φ=.3、噪声σ=1；10个±2信号均在前100列，S100/S200/S400只截列，共享y与行号。X、支撑/符号、噪声、划分分别为独立PCG64 seed2101、2102、2103、20261021。','', 'λ_max=||X.T@y||∞/n。DIA/S200固定比例.01/.03/.10/.30/1；E11/E12保持E02的绝对λ。没有用测试RMSE挑选λ。E01(DIA) λ=4.409499843964595；E02(S200) λ=.22281994907926272。','', '## 证据矩阵','']
lines+=table(['证据','问题','方法','每配置运行','summary总数','可以回答'],[
 ['original','E01–E12','四方法，来自各自机器','1 trace+3 timing','192','同问题数值正确性、正则/支撑、各host本地趋势'],
 ['same_machine_supplement','仅E01/E02','四份原solver，同一runner/进程/机器','1 trace+3 timing','32','这两个问题上这四份Python实现的同机效率与轨迹']])
lines+=['','原协议全部配置max_iterations=10000；DIA/S100/S200/S400预算分别10/20/30/45秒；主相对gap容差1e-6。新增补充完全继承E01/E02的配置，无调参。','', '## 统一停止与正确性','', '独立评价从β重算r=y−Xβ，构造对偶可行θ并计算D、带符号G=P−D。S=max(||y||²/(2n),1e-12)。停止要求量有限、G≥−1e-12S、对偶相对可行性违例≤1e-12、max(G,0)/S≤1e-6。原始CSV保留微小负gap，不以绝对值美化。','', '参考解使用独立sklearn Lasso(alpha=λ, fit_intercept=False, cyclic, tol=1e-13, max_iter=200000, precompute=False, warm_start=False, positive=False)，参考证书gap/S≤1e-10。目标差P−P_ref与通用gap是两件事，不能混淆。sklearn参考属于CD家族，其任务是认证数值值，不算第五个参赛算法。','', 'KKT分支使用真正的β=0；支撑统计阈值固定为1e-6 max(1,y_rms)，不裁剪最终β。ADMM残差仅作诊断，不能取代通用gap停止。','', '## 同机补充的计时','', '新增机器环境如下，同时列出原包方便识别不同host。六个包版本均为协议锁定版本；ISTA原Python不是正式要求的3.12.x。','']
lines+=table(['来源','CPU','物理核','RAM','Python','实际线程观测'],hostrows)
lines+=['','新增32次顺序执行，无并行实验。每个repeat按dataset循环，并按repeat+dataset_index旋转ISTA/FISTA/CD/ADMM顺序，使每方法在每问题的四轮各占一个位置。每次先做并丢弃10个warmup更新，再在计时内重新零初始化并重新setup，不复用优化状态或分解；“冷”指优化器状态，不表示清空CPU缓存。','', '统一计时从零β与初始证书前开始，包含每方法setup、主循环、有限性检查、状态快照和在线诊断。加载/校验数据、参考计算、warmup、预测/支撑指标、写盘和作图在计时外。trace每步诊断；timing每5步诊断，初始/强制末点必查。运行时间等于末点评价后的elapsed，setup+solve=runtime。','', '单线程环境变量在NumPy/SciPy导入前设为1，并使用threadpool_limits(1)。本Mac Accelerate未向threadpoolctl暴露活动线程池，故准确表述为“已请求单线程并记录环境”，不能说“实测线程数为1”。完整真实环境见 `supplement/environment.json`。','', '## 为什么迭代数不能直接等价为成本','']
lines+=table(['方法','setup主要成本','一次外层主要成本','共同证书另需'],[
 ['ISTA/FISTA','O(nd²+d³) Gram与谱值，O(d²)临时存储','O(nd)两次matvec；FISTA另有动量','O(nd)'],
 ['CD','O(nd)列范数','O(nd)，但Python逐d列；每10轮刷新残差','O(nd)'],
 ['ADMM','O(nd²+d³) Gram与Cholesky，O(d²)存储','O(d²)三角求解与向量更新','O(nd)']])
lines+=['','这些是本次实现边界内的稠密运算描述，不是从3个维度点拟合出的渐近复杂度。ISTA/FISTA谱值setup是协议固定实现选择；ADMM不计时外预分解；CD没有单独启用Numba/Cython。','', '## 统计与外推限制','', '- 每配置3个timing是同一确定性数据问题的计时重复，不是3份独立训练集。均值±标准差使用样本标准差（ddof=1），并同时保留中位数、min/max；它们不是置信区间。','- 两个同机问题不足以概括所有LASSO问题。FISTA的O(1/k²)理论目标上界不保证每个有限容差例子都比ISTA更早停止或耗时更少。FISTA目标可非单调，trace和timing也可能跨过不同的首次gap阈值。','- 合成只使用一组master与固定相关性/噪声；维度实验仅100/200/400，增加的是无直接真系数的列。没有额外seed、phi=.9或不同样本数的稳健性实验。','- ADMM固定ρ=1、无adaptive rho、无over-relaxation；没有完成ρ=.1/1/10敏感性试验，不能声称ρ最优。','- E06/E10在β=0初始认证结束，不执行求解器setup，必须从算法加速比排名排除。','- 这些是CPU/稠密Python实现；不能外推为所有库、硬件、规模或稀疏矩阵的普遍排名。LASSO一般不保证系数唯一，也不能无条件宣称强凸或线性收敛。','- 原始host之间的wall-clock不能直接排序。新增同机只有32次，不是协议12问题×4方法×4模式重复的正式192次同机完成声明。']
write('Experiment_Comparability.md',lines)

lines=['# Results Summary','', '合并证据共224次：原始192次加同机E01/E02补充32次。224份保存系数独立重算均达到共同相对gap≤1e-6，未发现失败或被删除的未收敛记录。`results_summary.json` 提供全部56组（48原始+8补充）数值与真实环境；`model_recomputation.json`逐模型记录检查。','', '## 同机E01/E02补充','', 'Apple M2，8核，8 GiB，Python3.12.5，六包遵守锁定版本。以下时间只用timing的3次测量，单位毫秒；标准差为样本SD，范围是实际min/max。均包含冷setup与在线公共诊断。','']
b=[]
for eid in ('E01','E02'):
    for alg in ('ISTA','FISTA','CD','ADMM'):
        g=grouped('same_machine_supplement',eid,alg)
        b.append([eid,alg,f"{1000*g['runtime_mean_seconds']:.4f} ± {1000*g['runtime_sample_std_seconds']:.4f}",f"{1000*g['runtime_median_seconds']:.4f}",f"[{1000*g['runtime_min_seconds']:.4f}, {1000*g['runtime_max_seconds']:.4f}]",g['trace_iterations'],'/'.join(map(str,g['timing_iterations']))])
lines+=table(['问题','方法','mean±sampleSD(ms)','median(ms)','min/max(ms)','trace更新','timing更新'],b)
lines+=['','CD的“更新”是一轮d个坐标，其余是一轮完整算法更新，不应只按迭代数评效率。此批次E01的CD时间中位数最低，E02的ADMM最低；这描述本次两个实例与四份Python实现。FISTA在E01的trace比ISTA少更新，但timing的5步检查和非单调gap让它停在105步，ISTA停在100步。E02的ISTA在49步trace达标，FISTA56步，说明理论加速上界不构成有限实例的逐例优势。','', '最终目标与精度（取trace末点；不是把P_ref称为精确P*）：','']
b=[]
for eid in ('E01','E02'):
    for alg in ('ISTA','FISTA','CD','ADMM'):
        g=grouped('same_machine_supplement',eid,alg);b.append([eid,alg,f"{g['final_objective']:.12f}",f"{g['relative_duality_gap']:.4e}",f"{g['test_rmse']:.6f}",g['nonzero_count']])
lines+=table(['问题','方法','P(β)','通用gap/S','test RMSE','非零数'],b)
lines+=['','各方法目标接近、预测/支撑也一致，但实际β和证书无需逐位相同。E01的共同数值目标约1791.58118443，E02约4.64244265616。','', '## 可用的FISTA振荡证据','']
b=[]
for eid in ('E01','E02'):
    h=[r for r in history if r['evidence_scope']=='same_machine_supplement' and r['algorithm']=='FISTA' and r['experiment_id']==eid and r['mode']=='trace']
    increases=[float(t['objective_value'])-float(s['objective_value']) for s,t in zip(h,h[1:])]
    b.append([eid,len(h)-1,sum(v>0 for v in increases),f'{max(increases):.9g}'])
lines+=table(['问题','trace完整更新数','P上升的更新数','最大单步P增加'],b)
lines+=['','原FISTA的这两个trace与同机补充得到相同数值轨迹；19次上升段不代表违反收敛或错误停止。应以独立通用gap确认精度，不把FISTA强行画成单调曲线。','', '## 正则化的共同数值现象（原始全网格）','', '以下范围覆盖四方法各自trace的保存模型；数据和λ相同，微小RMSE差来自停止点。固定网格不以测试集选参。','']
b=[]
for did,eids in [('DIA',['E03','E04','E01','E05','E06']),('S200',['E07','E08','E02','E09','E10'])]:
    for eid in eids:
        gs=[g for g in summary['aggregates'] if g['evidence_scope']=='original' and g['experiment_id']==eid]
        nnz=sorted(set(g['nonzero_count'] for g in gs));rm=[g['test_rmse'] for g in gs];f1=[g['support_f1'] for g in gs if g['support_f1'] is not None]
        b.append([did,eid,f"{gs[0]['lambda_ratio']:.2f}",'/'.join(map(str,nnz)),f'[{min(rm):.6f},{max(rm):.6f}]','—' if not f1 else f'[{min(f1):.3f},{max(f1):.3f}]'])
lines+=table(['数据','配置','λ/λmax','非零数','test RMSE四方法范围','support F1范围'],b)
lines+=['','S200在λ比例.10/.30均恢复10个真实支撑（F1=1），但测试RMSE约1.148/2.290，说明支撑准确并不消除收缩偏差。.03时RMSE约.983但选择21个变量；这只是一组固定问题上的观察。λ=λ_max时两数据集都在初始零解结束。','', '## 维度变化：只报告各自原host内趋势','', 'E11→E02→E12固定同一绝对λ和y，d=100→200→400。下表保持每个算法原host不变，不能横向当跨host速度排名；范围保留全部三次计时。','']
b=[]
for alg in ('ISTA','FISTA','CD','ADMM'):
    for eid in ('E11','E02','E12'):
        g=grouped('original',eid,alg);b.append([alg,g['host_label'],g['n_features'],f"{1000*g['runtime_mean_seconds']:.4f} ± {1000*g['runtime_sample_std_seconds']:.4f}",f"{1000*g['runtime_median_seconds']:.4f}",f"[{1000*g['runtime_min_seconds']:.4f},{1000*g['runtime_max_seconds']:.4f}]"])
lines+=table(['方法','原host','d','mean±sampleSD(ms)','median(ms)','min/max(ms)'],b)
lines+=['','ADMM原S100有约40.630ms的一次慢运行，未删除；3次timing不足以断言复杂度曲线。','', '## ADMM诊断与限制','', '原S200/E02的ADMM分裂残差在第19步已同时过阈值，通用gap到第29步才达标。初始r/s本来就是零，这再次表明残差诊断不能替代共同精度。ρ固定1，本次没有ρ敏感性试验；不能把本次成绩解释为调优后的最优ADMM。','', '单线程是导入前环境变量和threadpool_limits的请求；Accelerate没有暴露实际工作线程记录。原host混合、开发数据来源、缺共同干净Git commit、单一合成实例与3次计时的统计局限，详见 `Experiment_Comparability.md`。','', '## 重现','', '在final_presentation目录用Python3.12及 `reproduce/requirements.lock` 所列依赖运行：','', '```bash','python reproduce/integrate_results.py','python reproduce/run_comparison.py --output analysis/supplement-rerun','python reproduce/integrate_results.py --supplement analysis/supplement-rerun','python reproduce/write_analysis.py','```','', '第一条仅核验/合并保存的证据，不执行求解器。第二条新增32次，目标目录必须不存在；默认保留已有计时，不能覆盖原始结果。第三条选择新补充重新派生224行合并CSV。计时数值会随机器与调度变化；数据、λ、公式、容差和流程保持冻结。']
write('Results_Summary.md',lines)
print('Wrote Integration_Audit.md, Experiment_Comparability.md, Results_Summary.md and portable audits')
